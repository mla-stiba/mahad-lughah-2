import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/materi-mahasiswa — materi yang sudah dirilis (tanggalRilis <= now)
export async function GET(req: NextRequest) {
  const now = new Date()
  const materi = await db.materi.findMany({
    where: {
      tanggalRilis: { lte: now },
    },
    include: { level: true },
    orderBy: { tanggalRilis: 'desc' },
    take: 50,
  })
  return NextResponse.json({ data: materi })
}
