import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// ============ HASIL / DASHBOARD API ============
// GET /api/hasil?action=overview                  (overview semua)
// GET /api/hasil?action=by-kamar&sesiId=xxx
// GET /api/hasil?action=by-materi&sesiId=xxx     (item analysis)
// GET /api/hasil?action=by-mahasiswa&mahasiswaId=xxx
// GET /api/hasil?action=cross-tab&sesiId=xxx     (kamar x materi)
// GET /api/hasil?action=detail&hasilId=xxx       (detail satu hasil)
// GET /api/hasil?action=all&sesiId=xxx

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const action = searchParams.get('action')
  const sesiId = searchParams.get('sesiId')
  const mahasiswaId = searchParams.get('mahasiswaId')

  if (action === 'overview') {
    const [totalMhs, totalSesi, totalMateri, totalKamar] = await Promise.all([
      db.mahasiswa.count(),
      db.sesiUjian.count(),
      db.materi.count(),
      db.kamar.count(),
    ])

    const allHasil = await db.hasilUjian.findMany({
      where: { status: { in: ['submitted', 'graded'] } },
      select: {
        id: true,
        mahasiswaId: true,
        sesiId: true,
        skorTotal: true,
        jumlahBenar: true,
        jumlahSoal: true,
        selesai: true,
        mahasiswa: { include: { kamar: true } },
        sesi: { select: { nama: true, levelId: true } },
      },
    })

    const avgScore = allHasil.length > 0
      ? allHasil.reduce((sum, h) => sum + (h.skorTotal || 0), 0) / allHasil.length
      : 0

    // Group by sesi for trend
    const bySesi: Record<string, { nama: string; avg: number; count: number }> = {}
    for (const h of allHasil) {
      const key = h.sesiId
      if (!bySesi[key]) bySesi[key] = { nama: h.sesi.nama, avg: 0, count: 0 }
      bySesi[key].avg += h.skorTotal || 0
      bySesi[key].count += 1
    }
    Object.values(bySesi).forEach(s => { s.avg = s.avg / s.count })

    return NextResponse.json({
      data: {
        totalMhs,
        totalSesi,
        totalMateri,
        totalKamar,
        totalHasil: allHasil.length,
        avgScore,
        bySesi: Object.entries(bySesi).map(([id, v]) => ({ id, ...v })),
      },
    })
  }

  if (action === 'by-kamar') {
    const hasil = await db.hasilUjian.findMany({
      where: sesiId ? { sesiId } : { status: { in: ['submitted', 'graded'] } },
      include: { mahasiswa: { include: { kamar: true } }, sesi: true },
    })

    const byKamar: Record<string, { nama: string; avg: number; count: number; hasil: any[] }> = {}
    for (const h of hasil) {
      const k = h.mahasiswa.kamar
      if (!byKamar[k.id]) byKamar[k.id] = { nama: k.nama, avg: 0, count: 0, hasil: [] }
      byKamar[k.id].avg += h.skorTotal || 0
      byKamar[k.id].count += 1
      byKamar[k.id].hasil.push(h)
    }
    Object.values(byKamar).forEach(s => { s.avg = s.avg / s.count })

    return NextResponse.json({ data: Object.entries(byKamar).map(([id, v]) => ({ id, ...v })) })
  }

  if (action === 'by-materi') {
    // Item analysis: per soal, berapa % benar
    const sesi = await db.sesiUjian.findUnique({
      where: { id: sesiId! },
      include: { soal: { orderBy: { no: 'asc' }, include: { materi: true } } },
    })
    if (!sesi) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const detail = await db.detailHasil.findMany({
      where: { hasil: { sesiId: sesiId! } },
    })

    const bySoal: Record<string, { no: number; pertanyaan: string; arabic: string; benar: number; total: number }> = {}
    for (const soal of sesi.soal) {
      bySoal[soal.id] = {
        no: soal.no,
        pertanyaan: soal.pertanyaan,
        arabic: soal.pertanyaanArabic || soal.materi?.arabic || '',
        benar: 0,
        total: 0,
      }
    }
    for (const d of detail) {
      if (bySoal[d.soalId]) {
        bySoal[d.soalId].total += 1
        if (d.benar) bySoal[d.soalId].benar += 1
      }
    }

    return NextResponse.json({
      data: Object.entries(bySoal).map(([id, v]) => ({
        id,
        ...v,
        accuracy: v.total > 0 ? (v.benar / v.total) * 100 : 0,
      })),
    })
  }

  if (action === 'by-mahasiswa') {
    const hasil = await db.hasilUjian.findMany({
      where: { mahasiswaId: mahasiswaId!, status: { in: ['submitted', 'graded'] } },
      include: { sesi: true, detail: { include: { soal: true } } },
      orderBy: { selesai: 'asc' },
    })
    return NextResponse.json({ data: hasil })
  }

  if (action === 'cross-tab') {
    // Crosstab: kamar x materi (accuracy)
    const sesi = await db.sesiUjian.findUnique({
      where: { id: sesiId! },
      include: { soal: { orderBy: { no: 'asc' }, include: { materi: true } } },
    })
    if (!sesi) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const detail = await db.detailHasil.findMany({
      where: { hasil: { sesiId: sesiId! } },
      include: { hasil: { include: { mahasiswa: { include: { kamar: true } } } } },
    })

    // Map: kamar -> soalId -> {benar, total}
    const matrix: Record<string, { kamarNama: string; cells: Record<string, { benar: number; total: number; accuracy: number }> }> = {}
    for (const d of detail) {
      const kamarId = d.hasil.mahasiswa.kamar.id
      const kamarNama = d.hasil.mahasiswa.kamar.nama
      if (!matrix[kamarId]) matrix[kamarId] = { kamarNama, cells: {} }
      if (!matrix[kamarId].cells[d.soalId]) {
        matrix[kamarId].cells[d.soalId] = { benar: 0, total: 0, accuracy: 0 }
      }
      matrix[kamarId].cells[d.soalId].total += 1
      if (d.benar) matrix[kamarId].cells[d.soalId].benar += 1
    }
    Object.values(matrix).forEach(k => {
      Object.values(k.cells).forEach(c => {
        c.accuracy = c.total > 0 ? (c.benar / c.total) * 100 : 0
      })
    })

    return NextResponse.json({
      data: {
        soal: sesi.soal.map(s => ({ id: s.id, no: s.no, arabic: s.pertanyaanArabic || s.materi?.arabic || s.pertanyaan, arti: s.materi?.arti })),
        matrix: Object.entries(matrix).map(([kamarId, v]) => ({ kamarId, ...v })),
      },
    })
  }

  if (action === 'detail') {
    const hasilId = searchParams.get('hasilId')
    const hasil = await db.hasilUjian.findUnique({
      where: { id: hasilId! },
      include: {
        sesi: { include: { soal: { orderBy: { no: 'asc' }, include: { materi: true } } } },
        mahasiswa: { include: { kamar: true, level: true } },
        detail: true,
      },
    })
    if (!hasil) return NextResponse.json({ error: 'Not found' }, { status: 404 })
    return NextResponse.json({ data: hasil })
  }

  if (action === 'all') {
    const hasil = await db.hasilUjian.findMany({
      where: sesiId ? { sesiId } : {},
      include: {
        sesi: true,
        mahasiswa: { include: { kamar: true } },
      },
      orderBy: { selesai: 'desc' },
    })
    return NextResponse.json({ data: hasil })
  }

  return NextResponse.json({ error: 'Action tidak dikenal' }, { status: 400 })
}
