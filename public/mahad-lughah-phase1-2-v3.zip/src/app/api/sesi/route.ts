import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// ============ SESI UJIAN + SOAL API ============
// GET  /api/sesi?levelId=&aktif=
// GET  /api/sesi?id=xxx   (detail dengan soal)
// POST /api/sesi          (create new)
// PATCH /api/sesi
// DELETE /api/sesi?id=xxx

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const id = searchParams.get('id')
  const levelId = searchParams.get('levelId')
  const aktif = searchParams.get('aktif')

  if (id) {
    const sesi = await db.sesiUjian.findUnique({
      where: { id },
      include: {
        level: true,
        soal: { orderBy: { no: 'asc' }, include: { materi: true } },
        hasil: { include: { mahasiswa: { include: { kamar: true } } } },
      },
    })
    if (!sesi) return NextResponse.json({ error: 'Not found' }, { status: 404 })
    return NextResponse.json({ data: sesi })
  }

  const sesiList = await db.sesiUjian.findMany({
    where: {
      ...(levelId && levelId !== 'all' ? { levelId } : {}),
      ...(aktif === 'true' ? { aktif: true } : aktif === 'false' ? { aktif: false } : {}),
    },
    include: {
      level: true,
      _count: { select: { soal: true, hasil: true } },
    },
    orderBy: { tanggalMulai: 'desc' },
  })
  return NextResponse.json({ data: sesiList })
}

export async function POST(req: NextRequest) {
  const body = await req.json()

  if (body.action === 'add-soal') {
    const soal = await db.soalUjian.create({
      data: {
        sesiId: body.sesiId,
        no: body.no,
        jenis: body.jenis,
        materiId: body.materiId || null,
        pertanyaan: body.pertanyaan,
        pertanyaanArabic: body.pertanyaanArabic || null,
        opsiJson: body.opsiJson || null,
        jawabanBenar: body.jawabanBenar || null,
        jawabanAlternatif: body.jawabanAlternatif || null,
        audioUrl: body.audioUrl || null,
        imageUrl: body.imageUrl || null,
        videoUrl: body.videoUrl || null,
        embedUrl: body.embedUrl || null,
        fase: body.fase || null,
        kategori: body.kategori || null,
        bobot: body.bobot ?? 1,
        tipeSkor: body.tipeSkor || 'benar_salah',
        hint: body.hint || null,
      },
    })
    return NextResponse.json({ data: soal })
  }

  if (body.action === 'delete-soal') {
    await db.soalUjian.delete({ where: { id: body.soalId } })
    return NextResponse.json({ success: true })
  }

  if (body.action === 'update-soal') {
    // Update soal yang sudah ada (manual edit)
    const soal = await db.soalUjian.update({
      where: { id: body.soalId },
      data: {
        ...(body.jenis !== undefined && { jenis: body.jenis }),
        ...(body.materiId !== undefined && { materiId: body.materiId || null }),
        ...(body.pertanyaan !== undefined && { pertanyaan: body.pertanyaan }),
        ...(body.pertanyaanArabic !== undefined && { pertanyaanArabic: body.pertanyaanArabic || null }),
        ...(body.opsiJson !== undefined && { opsiJson: body.opsiJson || null }),
        ...(body.jawabanBenar !== undefined && { jawabanBenar: body.jawabanBenar || null }),
        ...(body.jawabanAlternatif !== undefined && { jawabanAlternatif: body.jawabanAlternatif || null }),
        ...(body.audioUrl !== undefined && { audioUrl: body.audioUrl || null }),
        ...(body.imageUrl !== undefined && { imageUrl: body.imageUrl || null }),
        ...(body.videoUrl !== undefined && { videoUrl: body.videoUrl || null }),
        ...(body.embedUrl !== undefined && { embedUrl: body.embedUrl || null }),
        ...(body.fase !== undefined && { fase: body.fase || null }),
        ...(body.kategori !== undefined && { kategori: body.kategori || null }),
        ...(body.bobot !== undefined && { bobot: body.bobot }),
        ...(body.tipeSkor !== undefined && { tipeSkor: body.tipeSkor }),
        ...(body.hint !== undefined && { hint: body.hint || null }),
      },
    })
    return NextResponse.json({ data: soal })
  }

  if (body.action === 'save-peserta') {
    // Save peserta list (JSON array of NIMs)
    const sesi = await db.sesiUjian.update({
      where: { id: body.sesiId },
      data: { pesertaJson: body.pesertaJson }, // null = semua boleh, JSON array = filter
      include: { level: true, _count: { select: { soal: true, hasil: true } } },
    })
    return NextResponse.json({ data: sesi })
  }

  if (body.action === 'generate-from-script') {
    // Parse custom DSL script → buat soal
    // Format:
    // ## N. jenis
    // P: pertanyaan
    // AR: arabic
    // Opsi: a|b|c|d (MCQ only)
    // J: jawaban benar
    // Alt: ["alt1","alt2"] atau alt1,alt2
    // Hint: teks hint
    // Bobot: 1
    // Tipe Skor: benar_salah | 0_100 | A_B_C_D
    const { sesiId, script } = body
    if (!sesiId || !script) return NextResponse.json({ error: 'sesiId dan script required' }, { status: 400 })

    const sesi = await db.sesiUjian.findUnique({ where: { id: sesiId } })
    if (!sesi) return NextResponse.json({ error: 'Sesi tidak ditemukan' }, { status: 404 })

    // Get max no
    const existing = await db.soalUjian.findMany({
      where: { sesiId },
      orderBy: { no: 'desc' },
      take: 1,
    })
    let nextNo = existing[0]?.no ?? 0

    // Parse script: split by ## to get soal blocks
    const blocks = script.split(/^##\s*/m).filter((b: string) => b.trim())
    let created = 0
    const errors: string[] = []

    for (let blockIdx = 0; blockIdx < blocks.length; blockIdx++) {
      const block = blocks[blockIdx]
      try {
        const lines = block.split('\n').map((l: string) => l.trim()).filter(Boolean)
        // First line: "1. isian" or "isian" or "1. isian (other)"
        const firstLine = lines[0]
        const jenisMatch = firstLine.match(/(isian|mcq|terjemahan|matching|audio)/i)
        if (!jenisMatch) {
          errors.push(`Block ${blockIdx + 1}: jenis tidak ditemukan di baris pertama`)
          continue
        }
        const jenis = jenisMatch[1].toLowerCase()

        // Parse other lines
        const data: Record<string, string> = {}
        for (let i = 1; i < lines.length; i++) {
          const line = lines[i]
          const colonIdx = line.indexOf(':')
          if (colonIdx > 0) {
            const key = line.substring(0, colonIdx).trim().toLowerCase()
            const val = line.substring(colonIdx + 1).trim()
            data[key] = val
          }
        }

        const pertanyaan = data['p'] || data['pertanyaan'] || data['soal'] || ''
        if (!pertanyaan) {
          errors.push(`Block ${blockIdx + 1}: pertanyaan (P:) kosong`)
          continue
        }

        nextNo += 1

        let opsiJson: string | null = null
        if (jenis === 'mcq' && data['opsi']) {
          const opsiArr = data['opsi'].split('|').map((s: string) => s.trim()).filter(Boolean)
          opsiJson = JSON.stringify(opsiArr)
        }

        const bobot = data['bobot'] ? parseFloat(data['bobot']) : 1

        await db.soalUjian.create({
          data: {
            sesiId,
            no: nextNo,
            jenis,
            pertanyaan,
            pertanyaanArabic: data['ar'] || data['arabic'] || null,
            opsiJson,
            jawabanBenar: data['j'] || data['jawaban'] || null,
            audioUrl: data['audio'] || data['audiourl'] || null,
            imageUrl: data['gambar'] || data['image'] || data['imageurl'] || null,
            videoUrl: data['video'] || data['videourl'] || null,
            embedUrl: data['embed'] || data['embedurl'] || null,
            fase: data['fase'] ? parseInt(data['fase']) : null,
            kategori: data['kategori'] || null,
            bobot,
          },
        })
        created++
      } catch (e: any) {
        errors.push(`Block ${blockIdx + 1}: ${e.message}`)
      }
    }

    return NextResponse.json({ success: true, created, errors: errors.slice(0, 10) })
  }

  // Create sesi
  const sesi = await db.sesiUjian.create({
    data: {
      nama: body.nama,
      levelId: body.levelId,
      mode: body.mode || 'online',
      durasiMenit: body.durasiMenit || 30,
      tanggalMulai: body.tanggalMulai ? new Date(body.tanggalMulai) : new Date(),
      aktif: body.aktif ?? true,
      acakUrutan: body.acakUrutan ?? false,
      jumlahSoalPerMahasiswa: body.jumlahSoalPerMahasiswa ?? null,
      jamMulai: body.jamMulai ?? null,
      jamSelesai: body.jamSelesai ?? null,
      pesertaJson: body.pesertaJson ?? null,
      gunakanFase: body.gunakanFase ?? false,
    },
    include: { level: true, _count: { select: { soal: true, hasil: true } } },
  })
  return NextResponse.json({ data: sesi })
}

export async function PATCH(req: NextRequest) {
  const body = await req.json()
  const updated = await db.sesiUjian.update({
    where: { id: body.id },
    data: {
      ...(body.nama !== undefined && { nama: body.nama }),
      ...(body.mode !== undefined && { mode: body.mode }),
      ...(body.durasiMenit !== undefined && { durasiMenit: body.durasiMenit }),
      ...(body.aktif !== undefined && { aktif: body.aktif }),
      ...(body.acakUrutan !== undefined && { acakUrutan: body.acakUrutan }),
      ...(body.jumlahSoalPerMahasiswa !== undefined && { jumlahSoalPerMahasiswa: body.jumlahSoalPerMahasiswa }),
      ...(body.tanggalMulai !== undefined && { tanggalMulai: body.tanggalMulai ? new Date(body.tanggalMulai) : new Date() }),
      ...(body.jamMulai !== undefined && { jamMulai: body.jamMulai || null }),
      ...(body.jamSelesai !== undefined && { jamSelesai: body.jamSelesai || null }),
      ...(body.pesertaJson !== undefined && { pesertaJson: body.pesertaJson || null }),
      ...(body.gunakanFase !== undefined && { gunakanFase: body.gunakanFase }),
      ...(body.tanggalSelesai !== undefined && { tanggalSelesai: body.tanggalSelesai ? new Date(body.tanggalSelesai) : null }),
    },
    include: { level: true, _count: { select: { soal: true, hasil: true } } },
  })
  return NextResponse.json({ data: updated })
}

export async function DELETE(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const id = searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })
  await db.sesiUjian.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
