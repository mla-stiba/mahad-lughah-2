import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// ============ UJIAN API (sisi mahasiswa) ============
// GET  /api/ujian?action=available&mahasiswaId=xxx
// GET  /api/ujian?action=detail&sesiId=xxx&mahasiswaId=xxx
// GET  /api/ujian?action=evaluasi&sesiId=xxx&mahasiswaId=xxx  (kunci jawaban setelah deadline)
// POST /api/ujian?action=start   { sesiId, mahasiswaId }
// POST /api/ujian?action=submit   { hasilId, jawaban: [{soalId, jawaban, audioUrl?}] }
// POST /api/ujian?action=retry    { sesiId, mahasiswaId } — coba ulang setelah deadline (tidak ubah nilai asli)
// POST /api/ujian?action=auto-submit { sesiId } — auto-submit semua yang telat (deadline passed)

function normalizeArabic(s: string): string {
  if (!s) return ''
  return s
    .replace(/[\u064B-\u0652\u0670\u0640]/g, '')
    .replace(/[إأآا]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .trim()
    .toLowerCase()
}

function checkJawaban(soal: any, jawaban: string): boolean {
  if (!jawaban) return false
  const normalized = normalizeArabic(jawaban)
  const benar = soal.jawabanBenar ? normalizeArabic(soal.jawabanBenar) : ''
  if (normalized === benar) return true
  if (soal.jawabanAlternatif) {
    try {
      const alts: string[] = JSON.parse(soal.jawabanAlternatif)
      return alts.some(a => normalizeArabic(a) === normalized)
    } catch {}
  }
  return false
}

// Check if deadline has passed (tanggalMulai + jamSelesai)
function isDeadlinePassed(sesi: any): boolean {
  if (!sesi.jamSelesai) return false // no deadline set
  const now = new Date()
  const deadlineDate = sesi.tanggalMulai ? new Date(sesi.tanggalMulai) : new Date()
  // Parse jamSelesai (HH:MM) and set on deadlineDate
  const [hours, minutes] = sesi.jamSelesai.split(':').map(Number)
  deadlineDate.setHours(hours, minutes, 0, 0)
  return now > deadlineDate
}

// Check if mahasiswa is allowed to take the exam (pesertaJson filter)
function isMahasiswaAllowed(sesi: any, nim: string): boolean {
  if (!sesi.pesertaJson) return true // null = semua boleh
  try {
    const allowedNims: string[] = JSON.parse(sesi.pesertaJson)
    if (allowedNims.length === 0) return true // empty array = semua boleh
    return allowedNims.includes(nim)
  } catch {
    return true // parse error = allow all
  }
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const action = searchParams.get('action')
  const mahasiswaId = searchParams.get('mahasiswaId')
  const sesiId = searchParams.get('sesiId')

  if (action === 'available') {
    const mhs = await db.mahasiswa.findUnique({ where: { id: mahasiswaId! } })
    if (!mhs) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const sesiList = await db.sesiUjian.findMany({
      where: { aktif: true },
      include: {
        level: true,
        _count: { select: { soal: true } },
        hasil: { where: { mahasiswaId: mhs.id } },
      },
      orderBy: { tanggalMulai: 'desc' },
    })

    // Filter by pesertaJson
    const allowedSesi = sesiList.filter(s => isMahasiswaAllowed(s, mhs.nim))

    // Check deadline status for each sesi
    const sesiWithStatus = allowedSesi.map(s => ({
      ...s,
      deadlinePassed: isDeadlinePassed(s),
    }))

    return NextResponse.json({ data: sesiWithStatus })
  }

  if (action === 'detail') {
    const sesi = await db.sesiUjian.findUnique({
      where: { id: sesiId! },
      include: {
        level: true,
        soal: { orderBy: { no: 'asc' }, include: { materi: true } },
      },
    })
    if (!sesi) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const mhs = await db.mahasiswa.findUnique({ where: { id: mahasiswaId! } })
    if (!mhs) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    // Check peserta access
    if (!isMahasiswaAllowed(sesi, mhs.nim)) {
      return NextResponse.json({ error: 'Anda tidak terdaftar sebagai peserta ujian ini' }, { status: 403 })
    }

    const hasil = await db.hasilUjian.findFirst({
      where: { sesiId: sesiId!, mahasiswaId: mahasiswaId! },
      include: { detail: true },
    })

    // ===== RANDOMISASI PER MAHASISWA =====
    let soalUntukMahasiswa = sesi.soal
    if (sesi.acakUrutan || sesi.jumlahSoalPerMahasiswa) {
      const seedStr = `${mahasiswaId}-${sesiId}`
      let seed = 0
      for (let i = 0; i < seedStr.length; i++) {
        seed = ((seed << 5) - seed) + seedStr.charCodeAt(i)
        seed |= 0
      }
      const prng = () => {
        let t = (seed += 0x6D2B79F5)
        t = Math.imul(t ^ (t >>> 15), t | 1)
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296
      }

      if (sesi.gunakanFase) {
        // ===== SHUFFLE PER FASE =====
        // Group soal by fase, shuffle within each fase, then concatenate fase 1 → 2 → 3...
        const faseGroups: Record<number, any[]> = {}
        const noFase: any[] = []
        for (const s of sesi.soal) {
          const f = s.fase || 0
          if (f > 0) {
            if (!faseGroups[f]) faseGroups[f] = []
            faseGroups[f].push(s)
          } else {
            noFase.push(s) // soal tanpa fase = ditaruh di akhir
          }
        }
        const sortedFases = Object.keys(faseGroups).map(Number).sort((a, b) => a - b)
        let shuffled: any[] = []
        for (const fase of sortedFases) {
          const group = [...faseGroups[fase]]
          for (let i = group.length - 1; i > 0; i--) {
            const j = Math.floor(prng() * (i + 1))
            ;[group[i], group[j]] = [group[j], group[i]]
          }
          // Ambil subset per fase jika jumlahSoalPerMahasiswa di-set
          if (sesi.jumlahSoalPerMahasiswa) {
            const perFase = Math.ceil(sesi.jumlahSoalPerMahasiswa / sortedFases.length)
            shuffled.push(...group.slice(0, perFase))
          } else {
            shuffled.push(...group)
          }
        }
        // Tambah soal tanpa fase di akhir
        for (let i = noFase.length - 1; i > 0; i--) {
          const j = Math.floor(prng() * (i + 1))
          ;[noFase[i], noFase[j]] = [noFase[j], noFase[i]]
        }
        shuffled.push(...noFase)
        // Limit total jika perlu
        if (sesi.jumlahSoalPerMahasiswa && shuffled.length > sesi.jumlahSoalPerMahasiswa) {
          shuffled = shuffled.slice(0, sesi.jumlahSoalPerMahasiswa)
        }
        soalUntukMahasiswa = shuffled
      } else {
        // ===== SHUFFLE GLOBAL (sebelumnya) =====
        const shuffled = [...sesi.soal]
        for (let i = shuffled.length - 1; i > 0; i--) {
          const j = Math.floor(prng() * (i + 1))
          ;[shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]]
        }
        if (sesi.jumlahSoalPerMahasiswa && sesi.jumlahSoalPerMahasiswa < shuffled.length) {
          soalUntukMahasiswa = shuffled.slice(0, sesi.jumlahSoalPerMahasiswa)
        } else {
          soalUntukMahasiswa = shuffled
        }
      }
    }

    // ===== ANTI-CHEAT: STRIP JAWABAN BENAR =====
    const soalSanitized = soalUntukMahasiswa.map(s => {
      const pertanyaanArabicSafe =
        s.pertanyaanArabic && s.jawabanBenar &&
        s.pertanyaanArabic.trim() === s.jawabanBenar.trim()
          ? null
          : s.pertanyaanArabic
      return {
        ...s,
        pertanyaanArabic: pertanyaanArabicSafe,
        jawabanBenar: undefined,
        jawabanAlternatif: undefined,
      }
    })

    // Check deadline status
    const deadlinePassed = isDeadlinePassed(sesi)

    const sesiWithShuffled = { ...sesi, soal: soalSanitized, deadlinePassed }

    return NextResponse.json({ data: { sesi: sesiWithShuffled, hasil } })
  }

  if (action === 'evaluasi') {
    // Evaluasi: kunci jawaban + jawaban mahasiswa, hanya jika deadline passed
    const sesi = await db.sesiUjian.findUnique({
      where: { id: sesiId! },
      include: { soal: { orderBy: { no: 'asc' } } },
    })
    if (!sesi) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    // Check deadline
    if (!isDeadlinePassed(sesi)) {
      return NextResponse.json({ error: 'Evaluasi baru tersedia setelah batas waktu ujian berakhir' }, { status: 403 })
    }

    // Check mahasiswa has submitted
    const hasil = await db.hasilUjian.findFirst({
      where: { sesiId: sesiId!, mahasiswaId: mahasiswaId! },
      include: { detail: true },
    })
    if (!hasil || (hasil.status !== 'submitted' && hasil.status !== 'graded')) {
      return NextResponse.json({ error: 'Anda harus mengumpulkan ujian terlebih dahulu' }, { status: 403 })
    }

    // Apply same randomization for this mahasiswa (same seed)
    let soalUntukMahasiswa = sesi.soal
    if (sesi.acakUrutan || sesi.jumlahSoalPerMahasiswa) {
      const seedStr = `${mahasiswaId}-${sesiId}`
      let seed = 0
      for (let i = 0; i < seedStr.length; i++) {
        seed = ((seed << 5) - seed) + seedStr.charCodeAt(i)
        seed |= 0
      }
      const prng = () => {
        let t = (seed += 0x6D2B79F5)
        t = Math.imul(t ^ (t >>> 15), t | 1)
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296
      }
      const shuffled = [...sesi.soal]
      for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(prng() * (i + 1))
        ;[shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]]
      }
      if (sesi.jumlahSoalPerMahasiswa && sesi.jumlahSoalPerMahasiswa < shuffled.length) {
        soalUntukMahasiswa = shuffled.slice(0, sesi.jumlahSoalPerMahasiswa)
      } else {
        soalUntukMahasiswa = shuffled
      }
    }

    // Return soal WITH jawabanBenar (for evaluasi) + hasil detail
    return NextResponse.json({
      data: {
        sesi: { ...sesi, soal: soalUntukMahasiswa },
        hasil,
      },
    })
  }

  return NextResponse.json({ error: 'Action tidak dikenal' }, { status: 400 })
}

export async function POST(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const action = searchParams.get('action')
  const body = await req.json()

  if (action === 'start') {
    let hasil = await db.hasilUjian.findFirst({
      where: { sesiId: body.sesiId, mahasiswaId: body.mahasiswaId },
    })
    if (!hasil) {
      const sesi = await db.sesiUjian.findUnique({
        where: { id: body.sesiId },
        include: { soal: true },
      })

      // Calculate actual soal count for this mahasiswa (after randomization/subset)
      let actualSoalCount = sesi?.soal.length || 0
      if (sesi?.jumlahSoalPerMahasiswa && sesi.jumlahSoalPerMahasiswa < actualSoalCount) {
        actualSoalCount = sesi.jumlahSoalPerMahasiswa
      }

      hasil = await db.hasilUjian.create({
        data: {
          sesiId: body.sesiId,
          mahasiswaId: body.mahasiswaId,
          status: 'ongoing',
          jumlahSoal: actualSoalCount, // subset count, bukan total
        },
      })
    }
    return NextResponse.json({ data: hasil })
  }

  if (action === 'submit') {
    const hasil = await db.hasilUjian.findUnique({
      where: { id: body.hasilId },
      include: { sesi: { include: { soal: true } } },
    })
    if (!hasil) return NextResponse.json({ error: 'Hasil tidak ditemukan' }, { status: 404 })

    let jumlahBenar = 0
    let skorTotal = 0
    let totalBobot = 0

    await db.detailHasil.deleteMany({ where: { hasilId: hasil.id } })

    for (const jawabanItem of body.jawaban) {
      const soal = hasil.sesi.soal.find(s => s.id === jawabanItem.soalId)
      if (!soal) continue

      let benar = false
      let skor = 0

      if (soal.jenis === 'mcq' || soal.jenis === 'isian' || soal.jenis === 'terjemahan' || soal.jenis === 'audio') {
        benar = checkJawaban(soal, jawabanItem.jawaban)
      }

      if (benar) {
        jumlahBenar++
        skor = soal.bobot
      }
      skorTotal += skor
      totalBobot += soal.bobot

      await db.detailHasil.create({
        data: {
          hasilId: hasil.id,
          soalId: soal.id,
          jawaban: jawabanItem.jawaban,
          skor,
          benar,
          status: 'graded',
          gradedAt: new Date(),
        },
      })
    }

    const updated = await db.hasilUjian.update({
      where: { id: hasil.id },
      data: {
        status: 'submitted',
        selesai: new Date(),
        jumlahBenar,
        jumlahSoal: body.jawaban.length, // jumlah soal yang dijawab = subset aktual
        skorTotal: body.jawaban.length > 0 ? (skorTotal / totalBobot) * 100 : 0,
      },
    })

    return NextResponse.json({ data: updated })
  }

  if (action === 'retry') {
    // Retry: create a NEW hasil record (doesn't affect original score)
    // Only allowed after deadline passed
    const sesi = await db.sesiUjian.findUnique({ where: { id: body.sesiId } })
    if (!sesi) return NextResponse.json({ error: 'Sesi tidak ditemukan' }, { status: 404 })

    if (!isDeadlinePassed(sesi)) {
      return NextResponse.json({ error: 'Coba ulang hanya tersedia setelah batas waktu ujian berakhir' }, { status: 403 })
    }

    // Check mahasiswa has submitted the original
    const originalHasil = await db.hasilUjian.findFirst({
      where: { sesiId: body.sesiId, mahasiswaId: body.mahasiswaId },
    })
    if (!originalHasil || (originalHasil.status !== 'submitted' && originalHasil.status !== 'graded')) {
      return NextResponse.json({ error: 'Anda harus mengumpulkan ujian terlebih dahulu sebelum coba ulang' }, { status: 403 })
    }

    // Create a NEW hasil record for retry (marked with status 'retry')
    const retryHasil = await db.hasilUjian.create({
      data: {
        sesiId: body.sesiId,
        mahasiswaId: body.mahasiswaId,
        status: 'ongoing',
        jumlahSoal: originalHasil.jumlahSoal,
        catatan: 'RETRY - tidak mempengaruhi nilai asli',
      },
    })

    return NextResponse.json({ data: retryHasil })
  }

  if (action === 'auto-submit') {
    // Auto-submit all ongoing hasil where deadline has passed
    const sesi = await db.sesiUjian.findUnique({
      where: { id: body.sesiId },
      include: { soal: true, hasil: { where: { status: 'ongoing' }, include: { detail: true } } },
    })
    if (!sesi) return NextResponse.json({ error: 'Sesi tidak ditemukan' }, { status: 404 })

    if (!isDeadlinePassed(sesi)) {
      return NextResponse.json({ error: 'Batas waktu belum berakhir' }, { status: 400 })
    }

    let autoSubmitted = 0
    for (const hasil of sesi.hasil) {
      // Calculate score from whatever detail exists
      let jumlahBenar = 0
      let skorTotal = 0
      let totalBobot = 0

      for (const detail of hasil.detail) {
        const soal = sesi.soal.find(s => s.id === detail.soalId)
        if (!soal) continue
        if (detail.benar === true) {
          jumlahBenar++
          skorTotal += soal.bobot
        }
        totalBobot += soal.bobot
      }

      await db.hasilUjian.update({
        where: { id: hasil.id },
        data: {
          status: 'submitted',
          selesai: new Date(),
          jumlahBenar,
          skorTotal: totalBobot > 0 ? (skorTotal / totalBobot) * 100 : 0,
        },
      })
      autoSubmitted++
    }

    return NextResponse.json({ success: true, autoSubmitted })
  }

  return NextResponse.json({ error: 'Action tidak dikenal' }, { status: 400 })
}
