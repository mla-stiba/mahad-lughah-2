import type { Metadata } from "next";
import { Plus_Jakarta_Sans, Amiri, Playfair_Display } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const jakartaSans = Plus_Jakarta_Sans({
  variable: "--font-jakarta",
  subsets: ["latin"],
  weight: ["400", "600", "700"], // 3 weight cukup (reguler, semi-bold, bold) - hemat ~60KB
  display: "swap", // tampilkan text pakai fallback dulu, ganti setelah font load
});

const amiri = Amiri({
  variable: "--font-amiri",
  subsets: ["arabic", "latin"],
  weight: ["400", "700"],
  display: "swap",
});

const playfair = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin"],
  weight: ["400", "600", "700"], // kurangi dari 5 weight jadi 3, hapus italic (jarang dipakai)
  display: "swap",
});

export const metadata: Metadata = {
  title: "Ma'had Lughah IAI STIBA Makassar",
  description: "Sistem Pengembangan Bahasa Arab Ma'had Lughah IAI STIBA Makassar. Ujian hafalan mufrodat & tarkib dengan evaluasi terstruktur.",
  keywords: ["Arabic", "mufrodat", "tarkib", "Ma'had Lughah", "IAI STIBA Makassar", "pengembangan bahasa"],
  authors: [{ name: "Ma'had Lughah IAI STIBA Makassar" }],
  icons: {
    icon: "/branding/logo-berwarna-indo.png",
    apple: "/branding/logo-berwarna-indo.png",
  },
  openGraph: {
    title: "Ma'had Lughah IAI STIBA Makassar",
    description: "Sistem Pengembangan Bahasa Arab",
    images: ["/branding/logo-berwarna-indo.png"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <head>
        {/* PWA manifest + theme color */}
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#1E2A78" />
        {/* Nonaktifkan auto-fullscreen mode (PWA standalone) supaya tetap ada address bar browser */}
        <meta name="apple-mobile-web-app-capable" content="no" />
        <meta name="mobile-web-app-capable" content="no" />
        {/* iOS PWA tetap bisa di-add to home screen dengan title */}
        <meta name="apple-mobile-web-app-title" content="Ma'had Lughah" />
        <link rel="apple-touch-icon" href="/branding/logo-berwarna-indo.png" />
      </head>
      <body
        className={`${jakartaSans.variable} ${amiri.variable} ${playfair.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
