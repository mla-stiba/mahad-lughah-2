'use client'

import { useEffect, useState } from 'react'

// ============ ANTI-CHEAT HOOK (untuk halaman ujian) ============
// Implementasi:
// 1. CSS user-select: none + disable context menu (block copy text)
// 2. Block keyboard shortcut: Ctrl+C, Ctrl+A, Ctrl+P, PrintScreen, Ctrl+S, F12, Ctrl+Shift+I
// 3. Detect window blur saat keydown (kemungkinan user buka screenshot tool)
// 4. Tampilkan overlay warning saat attempt terdeteksi
//
// CATATAN PENTING:
// - Browser TIDAK mengizinkan block screenshot 100% (lightshot, Snipping Tool, HP screenshot tidak bisa dicegah)
// - Yang kita bisa lakukan: block keyboard shortcut standar + deteksi + kasih peringatan
// - Untuk anti-copy text: CSS user-select: none + block Ctrl+C
//
// Sumber: https://developer.mozilla.org/en-US/docs/Web/CSS/user-select
//         https://developer.mozilla.org/en-US/docs/Web/API/Element/copy_event

export type AntiCheatViolation = {
  type: 'screenshot' | 'copy' | 'paste' | 'devtools' | 'print' | 'contextmenu' | 'blur'
  timestamp: number
}

export function useAntiCheat(enabled: boolean, onViolation?: (v: AntiCheatViolation) => void) {
  const [violations, setViolations] = useState<AntiCheatViolation[]>([])
  const [showWarning, setShowWarning] = useState(false)

  useEffect(() => {
    if (!enabled) return

    const addViolation = (type: AntiCheatViolation['type']) => {
      const v: AntiCheatViolation = { type, timestamp: Date.now() }
      setViolations((prev) => [...prev.slice(-9), v]) // simpan max 10 terakhir
      onViolation?.(v)
      setShowWarning(true)
      // Auto-hide warning setelah 3 detik
      setTimeout(() => setShowWarning(false), 3000)
    }

    // Block context menu (right-click)
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault()
      addViolation('contextmenu')
    }

    // Block keyboard shortcuts + detect PrintScreen
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase()
      const ctrl = e.ctrlKey || e.metaKey

      // Block: Ctrl+C, Ctrl+A, Ctrl+S, Ctrl+P, Ctrl+U, F12, Ctrl+Shift+I/J/C
      if (
        (ctrl && ['c', 'a', 's', 'p', 'u', 'x'].includes(key)) ||
        key === 'f12' ||
        (ctrl && e.shiftKey && ['i', 'j', 'c'].includes(key)) ||
        (ctrl && e.shiftKey && key === 'k') // Cmd+Shift+K (Mac)
      ) {
        e.preventDefault()
        addViolation('copy')
        return false
      }

      // Detect PrintScreen key (atau Win+Shift+S di Windows)
      if (
        key === 'printscreen' ||
        (e.code === 'PrintScreen') ||
        (e.altKey && key === 'printscreen')
      ) {
        // Coba clear clipboard
        try {
          navigator.clipboard?.writeText('')
        } catch {}
        addViolation('screenshot')
        return false
      }
    }

    // Detect copy/paste/cut events
    const handleCopy = (e: ClipboardEvent) => {
      e.preventDefault()
      addViolation('copy')
    }
    const handleCut = (e: ClipboardEvent) => {
      e.preventDefault()
      addViolation('copy')
    }

    // Detect window blur (kemungkinan user buka screenshot tool atau pindah tab)
    let lastBlurTime = 0
    const handleBlur = () => {
      const now = Date.now()
      // Throttle: max 1 event per 2 detik
      if (now - lastBlurTime < 2000) return
      lastBlurTime = now
      addViolation('blur')
    }

    // Detect devtools (sederhana - cek perubahan ukuran window)
    let devtoolsOpen = false
    const threshold = 160
    const checkDevtools = () => {
      const widthDiff = window.outerWidth - window.innerWidth
      const heightDiff = window.outerHeight - window.innerHeight
      const isOpen = widthDiff > threshold || heightDiff > threshold
      if (isOpen && !devtoolsOpen) {
        devtoolsOpen = true
        addViolation('devtools')
      } else if (!isOpen) {
        devtoolsOpen = false
      }
    }

    // Setup listeners
    document.addEventListener('contextmenu', handleContextMenu)
    document.addEventListener('keydown', handleKeyDown, true) // capture phase
    document.addEventListener('copy', handleCopy)
    document.addEventListener('cut', handleCut)
    window.addEventListener('blur', handleBlur)
    const devtoolsInterval = setInterval(checkDevtools, 1000)

    // Tambah CSS untuk disable selection + block drag image
    const style = document.createElement('style')
    style.id = 'anti-cheat-style'
    style.textContent = `
      body, .anti-cheat-zone, .anti-cheat-zone * {
        -webkit-user-select: none !important;
        -moz-user-select: none !important;
        -ms-user-select: none !important;
        user-select: none !important;
        -webkit-user-drag: none !important;
        -webkit-touch-callout: none !important;
      }
      .anti-cheat-zone input, .anti-cheat-zone textarea {
        -webkit-user-select: text !important;
        user-select: text !important;
      }
    `
    document.head.appendChild(style)

    // Cleanup
    return () => {
      document.removeEventListener('contextmenu', handleContextMenu)
      document.removeEventListener('keydown', handleKeyDown, true)
      document.removeEventListener('copy', handleCopy)
      document.removeEventListener('cut', handleCut)
      window.removeEventListener('blur', handleBlur)
      clearInterval(devtoolsInterval)
      style.remove()
    }
  }, [enabled, onViolation])

  return { violations, showWarning, setShowWarning }
}
