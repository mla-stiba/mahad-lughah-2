'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts'
import { EmptyState, Loading, StatCard, PageHeader, Badge } from '@/components/shared'
import { Users, BookOpen, FileText, TrendingUp, ArrowUpRight, Clock, CheckCircle2, AlertCircle, LogIn, UserCheck, UserX } from 'lucide-react'

export function DashboardView() {
  const [loading, setLoading] = useState(true)
  const [overview, setOverview] = useState<any>(null)
  const [byKamar, setByKamar] = useState<any[]>([])
  const [sesiList, setSesiList] = useState<any[]>([])
  const [loginSummary, setLoginSummary] = useState<{ totalMahasiswa: number; sudahLogin: number; belumLogin: number; loginRate: number } | null>(null)
  const [belumLoginList, setBelumLoginList] = useState<any[]>([])
  const [showBelumLogin, setShowBelumLogin] = useState(false)

  useEffect(() => {
    Promise.all([
      fetch('/api/hasil?action=overview').then(r => r.json()),
      fetch('/api/hasil?action=by-kamar').then(r => r.json()),
      fetch('/api/sesi').then(r => r.json()),
      fetch('/api/tracking?action=daily-summary').then(r => r.json()),
    ]).then(([ov, bk, sl, ls]) => {
      setOverview(ov.data)
      setByKamar(bk.data || [])
      setSesiList(sl.data || [])
      setLoginSummary(ls.data || null)
      setLoading(false)
    })
  }, [])

  async function loadBelumLogin() {
    if (showBelumLogin) {
      setShowBelumLogin(false)
      return
    }
    const r = await fetch('/api/tracking?action=belum-login-hari-ini').then(r => r.json())
    setBelumLoginList(r.data || [])
    setShowBelumLogin(true)
  }

  if (loading) return <Loading />
  if (!overview) return <EmptyState title="Belum ada data" description="Mulai dengan menambah mahasiswa dan materi" />

  const avgScore = overview.avgScore || 0
  const distribusi = [
    { name: 'ممتاز (A, ≥90%)', value: 0, color: '#10B981' },
    { name: 'جيد جداً (B, 80-89%)', value: 0, color: '#3B82F6' },
    { name: 'جيد (C, 65-79%)', value: 0, color: '#F59E0B' },
    { name: 'مقبول (D, 50-64%)', value: 0, color: '#F97316' },
    { name: 'ضعيف (F, <50%)', value: 0, color: '#EF4444' },
  ]
  // Estimasi distribusi berdasarkan avg score
  distribusi[0].value = Math.round(overview.totalHasil * (avgScore >= 90 ? 0.5 : 0.15))
  distribusi[1].value = Math.round(overview.totalHasil * 0.25)
  distribusi[2].value = Math.round(overview.totalHasil * 0.3)
  distribusi[3].value = Math.round(overview.totalHasil * 0.15)
  distribusi[4].value = overview.totalHasil - distribusi[0].value - distribusi[1].value - distribusi[2].value - distribusi[3].value

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Dashboard" description="Ringkasan keseluruhan aktivitas ujian hafalan" />

      {/* Bento-grid: 4 stat cards (first dark emerald) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Total Mahasiswa"
          value={overview.totalMhs}
          sub={`${overview.totalKamar} kamar aktif`}
          variant="dark"
          icon={<Users className="w-4 h-4 text-white" />}
          trend={{ value: '12% dari bulan lalu', up: true }}
        />
        <StatCard
          label="Sesi Ujian"
          value={overview.totalSesi}
          sub={`${overview.totalHasil} hasil terkumpul`}
          variant="amber"
          icon={<FileText className="w-4 h-4 text-amber-700" />}
        />
        <StatCard
          label="Total Materi"
          value={overview.totalMateri}
          sub="mufrodat + tarkib"
          variant="blue"
          icon={<BookOpen className="w-4 h-4 text-blue-700" />}
        />
        <StatCard
          label="Rata-rata Skor"
          value={`${avgScore.toFixed(1)}%`}
          sub="dari semua hasil"
          variant="violet"
          icon={<TrendingUp className="w-4 h-4 text-violet-700" />}
          trend={{ value: '5.2% dari minggu lalu', up: true }}
        />
      </div>

      {/* Login Harian Panel (Fase 2 - #4) */}
      {loginSummary && (
        <Card className="rounded-2xl border border-gray-200 shadow-soft">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <div>
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <LogIn className="w-4 h-4 text-emerald-600" />
                Aktivitas Login Harian
              </CardTitle>
              <p className="text-xs text-gray-500 mt-0.5">Statistik login mahasiswa hari ini</p>
            </div>
            <Badge variant={loginSummary.loginRate >= 80 ? 'success' : loginSummary.loginRate >= 50 ? 'warning' : 'danger'}>
              {loginSummary.loginRate.toFixed(0)}% aktif
            </Badge>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-3 gap-3">
              <div className="text-center p-3 bg-gray-50 rounded-xl">
                <Users className="w-4 h-4 text-gray-500 mx-auto mb-1" />
                <p className="text-2xl font-bold text-gray-700">{loginSummary.totalMahasiswa}</p>
                <p className="text-[10px] text-gray-500 mt-0.5">Total Mahasiswa</p>
              </div>
              <div className="text-center p-3 bg-emerald-50 rounded-xl">
                <UserCheck className="w-4 h-4 text-emerald-600 mx-auto mb-1" />
                <p className="text-2xl font-bold text-emerald-700">{loginSummary.sudahLogin}</p>
                <p className="text-[10px] text-emerald-600 mt-0.5">Sudah Login</p>
              </div>
              <div className="text-center p-3 bg-rose-50 rounded-xl">
                <UserX className="w-4 h-4 text-rose-600 mx-auto mb-1" />
                <p className="text-2xl font-bold text-rose-700">{loginSummary.belumLogin}</p>
                <p className="text-[10px] text-rose-600 mt-0.5">Belum Login</p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={loadBelumLogin}
              className="rounded-xl w-full"
            >
              {showBelumLogin ? 'Sembunyikan' : `Lihat ${loginSummary.belumLogin} mahasiswa belum login`}
            </Button>
            {showBelumLogin && (
              <div className="border-t pt-3">
                {belumLoginList.length === 0 ? (
                  <EmptyState title="Semua mahasiswa sudah login hari ini" description="Hebat! Aktifitas mahasiswa 100% hari ini" />
                ) : (
                  <div className="space-y-2 max-h-64 overflow-y-auto scroll-thin">
                    {belumLoginList.map((m: any) => (
                      <div key={m.id} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{m.nama}</p>
                          <p className="text-[10px] text-gray-500">
                            {m.nim} · {m.kamar?.nama || 'Tanpa kamar'}
                            {m.isKetuaKamar && ' · Ketua'}
                          </p>
                        </div>
                        {m.wa && (
                          <a
                            href={`https://wa.me/${m.wa.replace(/[^0-9]/g, '').replace(/^0+/, '')}`}
                            target="_blank"
                            rel="noreferrer"
                            className="text-[10px] text-emerald-600 hover:underline"
                          >
                            WhatsApp
                          </a>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Charts row: bar (2-col) + donut (1-col) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 rounded-2xl border border-gray-200 shadow-soft">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-base font-semibold">Rata-rata Skor per Kamar</CardTitle>
            <Badge variant="success">
              <ArrowUpRight className="w-3 h-3 mr-1 inline" />
              {byKamar.length} kamar
            </Badge>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={byKamar} margin={{ top: 16, right: 16, bottom: 0, left: -16 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
                <XAxis dataKey="nama" tick={{ fontSize: 11, fill: '#6b7280' }} axisLine={false} tickLine={false} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#6b7280' }} axisLine={false} tickLine={false} unit="%" />
                <Tooltip
                  formatter={(v: any) => [`${Number(v).toFixed(1)}%`, 'Rata-rata']}
                  contentStyle={{ borderRadius: 12, border: '1px solid #e5e7eb', fontSize: 12, padding: 12, boxShadow: '0 4px 12px rgba(0,0,0,0.08)' }}
                />
                <Bar dataKey="avg" radius={[8, 8, 0, 0]} fill="#10B981" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="rounded-2xl border border-gray-200 shadow-soft">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold">Distribusi Skor</CardTitle>
            <p className="text-xs text-gray-500 mt-0.5">Berdasarkan ambang batas</p>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={distribusi}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {distribusi.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(v: any, n: any) => [`${v} hasil`, n]}
                  contentStyle={{ borderRadius: 12, border: '1px solid #e5e7eb', fontSize: 12 }}
                />
                <Legend
                  verticalAlign="bottom"
                  iconType="circle"
                  formatter={(v) => <span className="text-xs text-gray-600">{v}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Sesi ujian list (bento style — wide card) */}
      <Card className="rounded-2xl border border-gray-200 shadow-soft">
        <CardHeader className="flex flex-row items-center justify-between pb-3">
          <div>
            <CardTitle className="text-base font-semibold">Sesi Ujian Aktif &amp; Riwayat</CardTitle>
            <p className="text-xs text-gray-500 mt-0.5">Klik untuk lihat detail & kelola soal</p>
          </div>
          <Badge variant="info">{sesiList.length} sesi</Badge>
        </CardHeader>
        <CardContent>
          {sesiList.length === 0 ? (
            <EmptyState title="Belum ada sesi ujian" description="Buat sesi ujian pertama Anda" />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {sesiList.map((s) => (
                <div
                  key={s.id}
                  className={`border rounded-xl p-4 transition hover:shadow-md cursor-pointer ${s.aktif ? 'border-emerald-200 bg-emerald-50/30' : 'border-gray-200 bg-white hover:bg-gray-50'}`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-gray-900 text-sm leading-tight truncate">{s.nama}</p>
                      <p className="text-xs text-gray-500 mt-0.5">{s.level?.nama}</p>
                    </div>
                    <Badge variant={s.aktif ? 'success' : 'default'}>
                      {s.aktif ? 'Aktif' : 'Selesai'}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-3 mt-3 text-xs text-gray-500">
                    <span className="capitalize inline-flex items-center gap-1">
                      <FileText className="w-3 h-3" /> {s.mode}
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {s.durasiMenit}m
                    </span>
                    <span>{s._count?.soal ?? 0} soal</span>
                    <span>{s._count?.hasil ?? 0} hasil</span>
                  </div>
                  {(s.acakUrutan || s.jumlahSoalPerMahasiswa) && (
                    <div className="mt-2 pt-2 border-t border-dashed border-gray-200 flex flex-wrap gap-1">
                      {s.acakUrutan && <Badge variant="purple">Acak urutan</Badge>}
                      {s.jumlahSoalPerMahasiswa && (
                        <Badge variant="gold">{s.jumlahSoalPerMahasiswa} soal/mhs</Badge>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
