'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { toast } from '@/hooks/use-toast'
import { ArabicText, EmptyState, Loading, Badge, PageHeader } from '@/components/shared'
import { FileUpload } from '@/components/shared/FileUpload'
import { Plus, Copy, Trash2, Shuffle, Settings2, FileCode2, Sparkles, Music, Edit2, Download, Eye, Image as ImageIcon, Video, Link as LinkIcon, Loader2, CheckCircle2 } from 'lucide-react'

export function SesiView() {
  const [loading, setLoading] = useState(true)
  const [list, setList] = useState<any[]>([])
  const [levelList, setLevelList] = useState<any[]>([])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editing, setEditing] = useState<any | null>(null)
  const [detailView, setDetailView] = useState<any | null>(null)
  const [materiList, setMateriList] = useState<any[]>([])

  const [form, setForm] = useState({
    nama: '', levelId: '', mode: 'online', durasiMenit: 30, aktif: true,
    acakUrutan: false, jumlahSoalPerMahasiswa: '' as string | number,
    tanggalMulai: new Date().toISOString().slice(0, 10),
    jamMulai: '', jamSelesai: '',
    gunakanFase: false,
  })

  // Soal builder form
  const [soalForm, setSoalForm] = useState({
    jenis: 'isian' as 'isian' | 'mcq',
    materiId: '',
    pertanyaan: '',
    pertanyaanArabic: '',
    opsi: ['', '', '', ''],
    jawabanBenar: '',
    jawabanBenarIndex: 0, // index opsi yang benar (untuk MCQ)
    audioUrl: '',
    imageUrl: '',
    videoUrl: '',
    embedUrl: '',
    fase: '',
    kategori: '',
    bobot: 1,
  })

  // Script generator
  const [scriptText, setScriptText] = useState(`## 1. isian
P: Tuliskan bahasa Arab: ayah
AR: أَبٌ
J: أَبٌ

## 2. mcq
P: Apa arti kata berikut?
AR: خُبْزٌ
Opsi: roti | nasi | air | gula
J: roti

## 3. mcq
P: Apa arti kata berikut?
AR: أُمٌّ
Opsi: ayah | ibu | anak | saudara
J: ibu
Fase: 1
Kategori: Mufrodat
`)

  async function load() {
    setLoading(true)
    const [sR, lR] = await Promise.all([
      fetch('/api/sesi').then(r => r.json()),
      fetch('/api/master?action=level').then(r => r.json()),
    ])
    setList(sR.data || [])
    setLevelList(lR.data || [])
    setLoading(false)
  }

  async function loadDetail() {
    if (!detailView) return
    const res = await fetch(`/api/sesi?id=${detailView.id}`).then(r => r.json())
    setDetailView(res.data)
  }

  useEffect(() => { load() }, [])

  function openCreate() {
    setEditing(null)
    setForm({
      nama: '', levelId: levelList[0]?.id || '', mode: 'online', durasiMenit: 30, aktif: true,
      acakUrutan: false, jumlahSoalPerMahasiswa: '',
      tanggalMulai: new Date().toISOString().slice(0, 10),
      jamMulai: '', jamSelesai: '',
      gunakanFase: false,
    })
    setDialogOpen(true)
  }

  function openEdit(s: any) {
    setEditing(s)
    setForm({
      nama: s.nama, levelId: s.levelId, mode: s.mode, durasiMenit: s.durasiMenit, aktif: s.aktif,
      acakUrutan: s.acakUrutan || false, jumlahSoalPerMahasiswa: s.jumlahSoalPerMahasiswa || '',
      tanggalMulai: s.tanggalMulai ? new Date(s.tanggalMulai).toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10),
      jamMulai: s.jamMulai || '', jamSelesai: s.jamSelesai || '',
      gunakanFase: s.gunakanFase || false,
    })
    setDialogOpen(true)
  }

  async function save() {
    if (!form.nama || !form.levelId) {
      toast({ title: 'Lengkapi data', variant: 'destructive' })
      return
    }
    const payload = {
      ...form,
      jumlahSoalPerMahasiswa: form.jumlahSoalPerMahasiswa === '' ? null : Number(form.jumlahSoalPerMahasiswa),
      tanggalMulai: form.tanggalMulai ? new Date(form.tanggalMulai) : new Date(),
    }
    const method = editing ? 'PATCH' : 'POST'
    const body = editing ? { id: editing.id, ...payload } : payload
    const res = await fetch('/api/sesi', {
      method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    })
    const data = await res.json()
    if (res.ok) {
      toast({ title: editing ? 'Diperbarui' : 'Sesi dibuat' })
      setDialogOpen(false)
      load()
    } else {
      toast({ title: 'Gagal', description: data.error, variant: 'destructive' })
    }
  }

  async function hapus(id: string) {
    if (!confirm('Hapus sesi ini + semua soal & hasilnya?')) return
    await fetch(`/api/sesi?id=${id}`, { method: 'DELETE' })
    toast({ title: 'Dihapus' })
    load()
  }

  async function openDetail(s: any) {
    const res = await fetch(`/api/sesi?id=${s.id}`).then(r => r.json())
    setDetailView(res.data)
    const matRes = await fetch(`/api/materi?levelId=${s.levelId}`).then(r => r.json())
    setMateriList(matRes.data || [])
    setSoalForm({
      jenis: 'isian', materiId: '', pertanyaan: '', pertanyaanArabic: '',
      opsi: ['', '', '', ''], jawabanBenar: '', jawabanBenarIndex: 0, audioUrl: '',
      imageUrl: '', videoUrl: '', embedUrl: '', fase: '', kategori: '',
      bobot: 1,
    })
  }

  async function addSoal() {
    if (!detailView) return
    const no = (detailView.soal?.length || 0) + 1
    // Auto-fill audioUrl dari materi kalau kosong & materi punya audioUrl
    let finalAudioUrl = soalForm.audioUrl
    if (!finalAudioUrl && soalForm.materiId) {
      const mat = materiList.find(m => m.id === soalForm.materiId)
      if (mat?.audioUrl) finalAudioUrl = mat.audioUrl
    }
    const res = await fetch('/api/sesi', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'add-soal',
        sesiId: detailView.id,
        no,
        jenis: soalForm.jenis,
        materiId: soalForm.materiId || null,
        pertanyaan: soalForm.pertanyaan,
        pertanyaanArabic: soalForm.pertanyaanArabic || null,
        opsiJson: soalForm.jenis === 'mcq' ? JSON.stringify(soalForm.opsi.filter(o => o.trim())) : null,
        jawabanBenar: soalForm.jenis === 'mcq' ? (soalForm.opsi[soalForm.jawabanBenarIndex] || soalForm.jawabanBenar) || null : (soalForm.jawabanBenar || null),
        audioUrl: finalAudioUrl || null,
        imageUrl: soalForm.imageUrl || null,
        videoUrl: soalForm.videoUrl || null,
        embedUrl: soalForm.embedUrl || null,
        fase: soalForm.fase ? parseInt(soalForm.fase) : null,
        kategori: soalForm.kategori || null,
        bobot: soalForm.bobot,
      }),
    })
    if (res.ok) {
      toast({ title: 'Soal ditambah' })
      // Reset form, keep jenis & skor
      setSoalForm({
        ...soalForm, pertanyaan: '', pertanyaanArabic: '', opsi: ['', '', '', ''],
        jawabanBenar: '', jawabanBenarIndex: 0, audioUrl: '', imageUrl: '', videoUrl: '', embedUrl: '', fase: '', kategori: '',
      })
      loadDetail()
    } else {
      const data = await res.json()
      toast({ title: 'Gagal', description: data.error, variant: 'destructive' })
    }
  }

  async function copySoal(soal: any) {
    if (!detailView) return
    const no = (detailView.soal?.length || 0) + 1
    const res = await fetch('/api/sesi', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'add-soal',
        sesiId: detailView.id,
        no,
        jenis: soal.jenis,
        materiId: soal.materiId,
        pertanyaan: soal.pertanyaan + ' (copy)',
        pertanyaanArabic: soal.pertanyaanArabic,
        opsiJson: soal.opsiJson,
        jawabanBenar: soal.jawabanBenar,

        audioUrl: soal.audioUrl,
        imageUrl: soal.imageUrl,
        videoUrl: soal.videoUrl,
        embedUrl: soal.embedUrl,
        fase: soal.fase || null,
        kategori: soal.kategori || null,
        bobot: soal.bobot,
        tipeSkor: soal.tipeSkor,
        hint: soal.hint,
      }),
    })
    if (res.ok) {
      toast({ title: 'Soal disalin' })
      loadDetail()
    }
  }

  async function hapusSoal(soalId: string) {
    if (!detailView) return
    if (!confirm('Hapus soal ini?')) return
    await fetch('/api/sesi', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'delete-soal', soalId }),
    })
    toast({ title: 'Soal dihapus' })
    loadDetail()
  }

  const [generating, setGenerating] = useState(false)
  const [generateResult, setGenerateResult] = useState<{ created: number; errors: string[] } | null>(null)

  async function generateFromScript() {
    if (!detailView) return
    if (!scriptText.trim()) {
      toast({ title: 'Script kosong', variant: 'destructive' })
      return
    }
    setGenerating(true)
    setGenerateResult(null)
    try {
      const res = await fetch('/api/sesi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'generate-from-script', sesiId: detailView.id, script: scriptText }),
      })
      const data = await res.json()
      if (res.ok) {
        setGenerateResult({ created: data.created || 0, errors: data.errors || [] })
        toast({
          title: `✅ Berhasil generate ${data.created} soal`,
          description: data.errors?.length ? `${data.errors.length} baris gagal — lihat detail di bawah` : 'Semua soal berhasil dibuat',
          variant: data.errors?.length ? 'destructive' : 'default',
        })
        loadDetail()
      } else {
        toast({ title: 'Gagal', description: data.error, variant: 'destructive' })
      }
    } catch (e: any) {
      toast({ title: 'Network error', description: e.message, variant: 'destructive' })
    } finally {
      setGenerating(false)
    }
  }

  // ===== EDIT SOAL =====
  const [editingSoal, setEditingSoal] = useState<any | null>(null)
  const [editSoalDialogOpen, setEditSoalDialogOpen] = useState(false)
  const [editSoalForm, setEditSoalForm] = useState<any>({})

  function openEditSoal(soal: any) {
    setEditingSoal(soal)
    setEditSoalForm({
      soalId: soal.id,
      jenis: soal.jenis,
      materiId: soal.materiId || '',
      pertanyaan: soal.pertanyaan,
      pertanyaanArabic: soal.pertanyaanArabic || '',
      opsi: soal.opsiJson ? JSON.parse(soal.opsiJson) : ['', '', '', ''],
      jawabanBenar: soal.jawabanBenar || '',
      jawabanBenarIndex: soal.jenis === 'mcq' && soal.opsiJson && soal.jawabanBenar ? (() => { try { const o = JSON.parse(soal.opsiJson); return Math.max(0, o.indexOf(soal.jawabanBenar)); } catch { return 0; } })() : 0,
      audioUrl: soal.audioUrl || '',
      imageUrl: soal.imageUrl || '',
      videoUrl: soal.videoUrl || '',
      embedUrl: soal.embedUrl || '',
      fase: soal.fase ? String(soal.fase) : '',
      kategori: soal.kategori || '',
      bobot: soal.bobot,
    })
    setEditSoalDialogOpen(true)
  }

  async function saveEditSoal() {
    if (!editingSoal) return
    const res = await fetch('/api/sesi', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'update-soal',
        soalId: editingSoal.id,
        jenis: editSoalForm.jenis,
        materiId: editSoalForm.materiId || null,
        pertanyaan: editSoalForm.pertanyaan,
        pertanyaanArabic: editSoalForm.pertanyaanArabic || null,
        opsiJson: editSoalForm.jenis === 'mcq' ? JSON.stringify(editSoalForm.opsi.filter((o: string) => o.trim())) : null,
        jawabanBenar: editSoalForm.jenis === 'mcq' ? (editSoalForm.opsi[editSoalForm.jawabanBenarIndex] || editSoalForm.jawabanBenar) || null : (editSoalForm.jawabanBenar || null),
        audioUrl: editSoalForm.audioUrl || null,
        imageUrl: editSoalForm.imageUrl || null,
        videoUrl: editSoalForm.videoUrl || null,
        embedUrl: editSoalForm.embedUrl || null,
        fase: editSoalForm.fase ? parseInt(editSoalForm.fase) : null,
        kategori: editSoalForm.kategori || null,
        bobot: editSoalForm.bobot,
      }),
    })
    if (res.ok) {
      toast({ title: 'Soal diperbarui' })
      setEditSoalDialogOpen(false)
      loadDetail()
    } else {
      const data = await res.json()
      toast({ title: 'Gagal', description: data.error, variant: 'destructive' })
    }
  }

  // ===== EXPORT SCRIPT =====
  function buildSoalScript(s: any): string {
    let script = `## ${s.no}. ${s.jenis}\n`
    script += `P: ${s.pertanyaan}\n`
    if (s.pertanyaanArabic) script += `AR: ${s.pertanyaanArabic}\n`
    if (s.jenis === 'mcq' && s.opsiJson) {
      try {
        const opsi = JSON.parse(s.opsiJson)
        script += `Opsi: ${opsi.join(' | ')}\n`
      } catch {}
    }
    if (s.jawabanBenar) script += `J: ${s.jawabanBenar}\n`
    if (s.audioUrl) script += `Audio: ${s.audioUrl}\n`
    if (s.imageUrl) script += `Gambar: ${s.imageUrl}\n`
    if (s.videoUrl) script += `Video: ${s.videoUrl}\n`
    if (s.embedUrl) script += `Embed: ${s.embedUrl}\n`
    if (s.fase) script += `Fase: ${s.fase}\n`
    if (s.kategori) script += `Kategori: ${s.kategori}\n`
    script += `Bobot: ${s.bobot}\n`
    return script
  }

  function exportSoalScript(s: any) {
    const script = buildSoalScript(s)
    navigator.clipboard.writeText(script).then(() => {
      toast({ title: 'Script soal disalin ke clipboard' })
    }).catch(() => {
      // Fallback: download as .txt
      const blob = new Blob([script], { type: 'text/plain' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `soal-${s.no}.txt`
      a.click()
      URL.revokeObjectURL(url)
    })
  }

  function exportAllScript() {
    if (!detailView) return
    const scripts = detailView.soal.map((s: any) => buildSoalScript(s)).join('\n')
    const blob = new Blob([scripts], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `script-ujian-${detailView.nama.replace(/[^a-zA-Z0-9]/g, '_')}.txt`
    a.click()
    URL.revokeObjectURL(url)
    toast({ title: `Export ${detailView.soal.length} soal ke script` })
  }

  // ===== PREVIEW UJIAN =====
  const [previewMode, setPreviewMode] = useState(false)

  if (loading) return <Loading />

  if (detailView) {
    return (
      <div className="space-y-6">
        <div>
          <Button variant="ghost" onClick={() => setDetailView(null)} className="mb-2">← Kembali ke daftar</Button>
          <PageHeader
            title={detailView.nama}
            description={`${detailView.level?.nama} · ${detailView.mode} · ${detailView.durasiMenit} menit · ${detailView.soal.length} soal`}
            action={
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={exportAllScript} disabled={detailView.soal.length === 0} className="rounded-xl">
                  <Download className="w-4 h-4 mr-1.5" /> Export Script
                </Button>
                <Button variant="outline" size="sm" onClick={() => setPreviewMode(!previewMode)} className="rounded-xl">
                  <Eye className="w-4 h-4 mr-1.5" /> {previewMode ? 'Keluar Preview' : 'Preview Ujian'}
                </Button>
              </div>
            }
          />
          {(detailView.acakUrutan || detailView.jumlahSoalPerMahasiswa) && (
            <div className="flex flex-wrap gap-2 mb-4">
              {detailView.acakUrutan && (
                <Badge variant="purple"><Shuffle className="w-3 h-3 mr-1 inline" /> Urutan soal diacak per mahasiswa</Badge>
              )}
              {detailView.jumlahSoalPerMahasiswa && (
                <Badge variant="gold">Ambil {detailView.jumlahSoalPerMahasiswa} dari {detailView.soal.length} soal per mahasiswa</Badge>
              )}
            </div>
          )}
          {/* Schedule display */}
          {(detailView.jamMulai || detailView.jamSelesai || detailView.tanggalMulai) && (
            <div className="flex items-center gap-2 mb-4 text-sm text-gray-600">
              <Badge variant="info">
                📅 {new Date(detailView.tanggalMulai).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}
              </Badge>
              {detailView.jamMulai && <Badge variant="default">⏰ {detailView.jamMulai} - {detailView.jamSelesai || '?'}</Badge>}
            </div>
          )}
        </div>

        {/* PREVIEW MODE — admin coba seperti mahasiswa */}
        {previewMode && (
          <Card className="rounded-2xl border-2 border-emerald-300 bg-emerald-50/30">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Eye className="w-4 h-4 text-emerald-600" /> Preview Mode (sebagai mahasiswa)
              </CardTitle>
              <p className="text-xs text-gray-500">Lihat soal seperti yang dilihat mahasiswa. Jawaban benar disembunyikan. Tidak ada submit sebenarnya.</p>
            </CardHeader>
            <CardContent className="space-y-4">
              {detailView.soal.map((s: any, i: number) => (
                <div key={s.id} className="bg-white rounded-xl p-4 border border-gray-200 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-emerald-700">#{i + 1}</span>
                    <Badge variant="info">{s.jenis}</Badge>
                  </div>
                  <p className="text-gray-800">{s.pertanyaan}</p>
                  {s.pertanyaanArabic && (
                    <ArabicText size="lg" className="text-emerald-700">{s.pertanyaanArabic}</ArabicText>
                  )}
                  {s.jenis === 'mcq' && s.opsiJson && (
                    <div className="space-y-1">
                      {JSON.parse(s.opsiJson).map((o: string, idx: number) => (
                        <div key={idx} className="p-2 border rounded-lg text-sm">○ {o}</div>
                      ))}
                    </div>
                  )}
                  {s.audioUrl && <audio controls src={s.audioUrl} className="w-full h-9" preload="none" />}
                  <p className="text-xs text-gray-400 italic">[Jawaban mahasiswa akan muncul di sini]</p>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="soal">
          <TabsList className="bg-gray-100 rounded-full p-1">
            <TabsTrigger value="soal" className="rounded-full data-[state=active]:bg-white data-[state=active]:shadow-sm">Daftar Soal ({detailView.soal.length})</TabsTrigger>
            <TabsTrigger value="add" className="rounded-full data-[state=active]:bg-white data-[state=active]:shadow-sm">
              <Plus className="w-3 h-3 mr-1 inline" /> Tambah Manual
            </TabsTrigger>
            <TabsTrigger value="script" className="rounded-full data-[state=active]:bg-white data-[state=active]:shadow-sm">
              <FileCode2 className="w-3 h-3 mr-1 inline" /> Script Generator
            </TabsTrigger>
            <TabsTrigger value="hasil" className="rounded-full data-[state=active]:bg-white data-[state=active]:shadow-sm">Hasil ({detailView.hasil?.length || 0})</TabsTrigger>
            <TabsTrigger value="peserta" className="rounded-full data-[state=active]:bg-white data-[state=active]:shadow-sm">Peserta</TabsTrigger>
          </TabsList>

          {/* Daftar Soal */}
          <TabsContent value="soal" className="space-y-3 mt-4">
            {detailView.soal.length === 0 ? (
              <Card className="rounded-2xl border-0 shadow-soft">
                <CardContent>
                  <EmptyState title="Belum ada soal" description="Tambah soal manual, copy dari soal lain, atau generate via script" />
                </CardContent>
              </Card>
            ) : (
              detailView.soal.map((s: any) => (
                <Card key={s.id} className="rounded-2xl border-0 shadow-soft hover:shadow-md transition">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-emerald-700">#{s.no}</span>
                          <Badge variant="info">{s.jenis}</Badge>
                          <Badge variant="default">{s.tipeSkor}</Badge>
                          <span className="text-xs text-gray-500">bobot {s.bobot}</span>
                          {s.fase && <Badge variant="purple">Fase {s.fase}</Badge>}
                          {s.kategori && <Badge variant="gold">{s.kategori}</Badge>}
                          {s.materi && <Badge variant="warning">{s.materi.jenis}</Badge>}
                        </div>
                        <p className="text-gray-800">{s.pertanyaan}</p>
                        {s.pertanyaanArabic && (
                          <div className="bg-emerald-50 rounded-xl p-3 text-right">
                            <ArabicText size="lg" className="text-emerald-800">{s.pertanyaanArabic}</ArabicText>
                          </div>
                        )}
                        {s.jenis === 'mcq' && s.opsiJson && (
                          <div className="text-sm text-gray-600 bg-gray-50 rounded-lg p-2">
                            Opsi: {JSON.parse(s.opsiJson).join(' | ')}
                          </div>
                        )}
                        {s.jawabanBenar && (
                          <p className="text-xs text-emerald-700 font-medium">Jawaban benar: {s.jawabanBenar}</p>
                        )}
                        {s.audioUrl && (
                          <div className="bg-emerald-50 rounded-lg p-2 space-y-1">
                            <p className="text-[10px] text-emerald-700 font-semibold uppercase tracking-wide">Audio (admin)</p>
                            <audio controls src={s.audioUrl} className="w-full h-8" preload="none" />
                          </div>
                        )}
                        {s.hint && <p className="text-xs text-gray-500">Hint: {s.hint}</p>}
                      </div>
                      <div className="flex flex-col gap-1">
                        <Button size="sm" variant="ghost" onClick={() => openEditSoal(s)} title="Edit soal" className="rounded-lg h-8 w-8 p-0">
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => copySoal(s)} title="Copy soal" className="rounded-lg h-8 w-8 p-0">
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => exportSoalScript(s)} title="Export script soal ini" className="rounded-lg h-8 w-8 p-0 text-emerald-600">
                          <Download className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost" className="text-rose-600 rounded-lg h-8 w-8 p-0" onClick={() => hapusSoal(s.id)} title="Hapus soal">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          {/* Tambah Manual */}
          <TabsContent value="add" className="space-y-4 mt-4">
            <Card className="rounded-2xl border-0 shadow-soft">
              <CardHeader>
                <CardTitle className="text-base">Tambah Soal Manual</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Jenis Soal</Label>
                    <Select value={soalForm.jenis} onValueChange={(v) => setSoalForm({ ...soalForm, jenis: v as any })}>
                      <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="isian">Isian / Hafalan</SelectItem>
                        <SelectItem value="mcq">Pilihan Ganda (MCQ)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Materi (opsional)</Label>
                    <Select value={soalForm.materiId || 'none'} onValueChange={(v) => setSoalForm({ ...soalForm, materiId: v === 'none' ? '' : v })}>
                      <SelectTrigger className="rounded-xl"><SelectValue placeholder="Tanpa materi" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">Tanpa materi</SelectItem>
                        {materiList.map(m => <SelectItem key={m.id} value={m.id}>{m.arabic} — {m.arti}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Pertanyaan (Indonesia)</Label>
                  <Textarea value={soalForm.pertanyaan} onChange={(e) => setSoalForm({ ...soalForm, pertanyaan: e.target.value })} rows={2} placeholder="Tuliskan kalimat Arabic berikut..." className="rounded-xl" />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Pertanyaan versi Arabic (untuk tampil RTL)</Label>
                  <Input value={soalForm.pertanyaanArabic} onChange={(e) => setSoalForm({ ...soalForm, pertanyaanArabic: e.target.value })} dir="rtl" className="font-arabic text-right text-xl rounded-xl" placeholder="مَا هَذَا؟" />
                </div>

                {soalForm.jenis === 'mcq' && (
                  <div className="space-y-2">
                    <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Opsi Jawaban (pilih jawaban benar dengan radio)</Label>
                    {soalForm.opsi.map((o, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <input
                          type="radio"
                          name="jawabanBenarMCQ"
                          checked={soalForm.jawabanBenarIndex === i}
                          onChange={() => setSoalForm({ ...soalForm, jawabanBenarIndex: i, jawabanBenar: o })}
                          className="w-4 h-4 accent-emerald-600 flex-shrink-0"
                        />
                        <Input
                          value={o}
                          onChange={(e) => {
                            const newOpsi = [...soalForm.opsi]
                            newOpsi[i] = e.target.value
                            const newJawaban = soalForm.jawabanBenarIndex === i ? e.target.value : soalForm.jawabanBenar
                            setSoalForm({ ...soalForm, opsi: newOpsi, jawabanBenar: newJawaban })
                          }}
                          placeholder={`Opsi ${i + 1}`}
                          className={`rounded-xl flex-1 ${soalForm.jawabanBenarIndex === i ? 'border-emerald-400 bg-emerald-50/30' : ''}`}
                        />
                        {soalForm.opsi.length > 2 && (
                          <button
                            onClick={() => {
                              const newOpsi = soalForm.opsi.filter((_, idx) => idx !== i)
                              const newIndex = soalForm.jawabanBenarIndex >= i ? Math.max(0, soalForm.jawabanBenarIndex - 1) : soalForm.jawabanBenarIndex
                              setSoalForm({ ...soalForm, opsi: newOpsi, jawabanBenarIndex: newIndex, jawabanBenar: newOpsi[newIndex] || '' })
                            }}
                            className="text-rose-500 hover:text-rose-700 flex-shrink-0"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    ))}
                    <Button size="sm" variant="outline" onClick={() => setSoalForm({ ...soalForm, opsi: [...soalForm.opsi, ''] })} className="rounded-full">+ Tambah opsi</Button>
                  </div>
                )}

                {/* Jawaban Benar untuk isian (text input, bukan radio) */}
                {soalForm.jenis === 'isian' && (
                  <div className="space-y-2">
                    <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Jawaban Benar</Label>
                    <Input value={soalForm.jawabanBenar} onChange={(e) => setSoalForm({ ...soalForm, jawabanBenar: e.target.value })} dir="rtl" className="font-arabic text-right text-xl rounded-xl" placeholder="أَبٌ" />
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Bobot</Label>
                    <Input type="number" step="0.5" value={soalForm.bobot} onChange={(e) => setSoalForm({ ...soalForm, bobot: parseFloat(e.target.value) || 1 })} className="rounded-xl" />
                  </div>
                </div>

                {/* Fase & Kategori (opsional) */}
                <div className="bg-violet-50 border border-violet-200 rounded-xl p-4 space-y-3">
                  <p className="text-sm font-semibold text-violet-800">Fase & Kategori Soal (opsional)</p>
                  <p className="text-xs text-gray-600">Bagi soal ke fase (1, 2, 3...) — soal diacak per fase. Kategori untuk evaluasi per kelompok soal.</p>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Fase (1, 2, 3...)</Label>
                      <Input
                        type="number"
                        value={soalForm.fase}
                        onChange={(e) => setSoalForm({ ...soalForm, fase: e.target.value })}
                        placeholder="Kosongkan jika tanpa fase"
                        min="1"
                        className="rounded-xl"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Kategori Soal</Label>
                      <Input
                        value={soalForm.kategori}
                        onChange={(e) => setSoalForm({ ...soalForm, kategori: e.target.value })}
                        placeholder="Mis. Mufrodat, Tarkib, Qira'ah..."
                        className="rounded-xl"
                      />
                    </div>
                  </div>
                </div>

                {/* Media fields — tampil untuk SEMUA jenis soal (gambar/embed/audio/video) */}
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 space-y-3">
                  <p className="text-sm font-semibold text-blue-800 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4" /> Media Soal (opsional)
                  </p>
                  <p className="text-xs text-gray-600">
                    Upload file langsung atau paste URL eksternal. Video YouTube bisa di-paste URL-nya.
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    <FileUpload label="Gambar" accept="image/*" value={soalForm.imageUrl} onChange={(v) => setSoalForm({ ...soalForm, imageUrl: v })} preview="image" />
                    <FileUpload label="Video" accept="video/*" value={soalForm.videoUrl} onChange={(v) => setSoalForm({ ...soalForm, videoUrl: v })} preview="video" />
                    <FileUpload label="Audio (mp3)" accept="audio/*" value={soalForm.audioUrl} onChange={(v) => setSoalForm({ ...soalForm, audioUrl: v })} preview="audio" />
                    <div className="space-y-1.5">
                      <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600 flex items-center gap-1">
                        <LinkIcon className="w-3 h-3" /> Embed URL (iframe)
                      </Label>
                      <Input
                        value={soalForm.embedUrl}
                        onChange={(e) => setSoalForm({ ...soalForm, embedUrl: e.target.value })}
                        placeholder="https://... (untuk embed di soal)"
                        className="rounded-xl text-sm"
                      />
                    </div>
                  </div>
                  {/* Preview media yang sudah diisi */}
                  {(soalForm.imageUrl || soalForm.videoUrl || soalForm.audioUrl) && (
                    <div className="mt-3 pt-3 border-t border-blue-200 space-y-2">
                      <p className="text-xs font-semibold text-gray-600">Preview:</p>
                      {soalForm.imageUrl && (
                        <img src={soalForm.imageUrl} alt="preview" className="max-h-32 rounded-lg border border-gray-200" />
                      )}
                      {soalForm.videoUrl && (
                        <p className="text-xs text-gray-600">📹 Video: <a href={soalForm.videoUrl} target="_blank" className="text-blue-600 hover:underline">{soalForm.videoUrl}</a></p>
                      )}
                      {soalForm.audioUrl && (
                        <audio controls src={soalForm.audioUrl} className="w-full h-9" preload="none" />
                      )}
                    </div>
                  )}
                </div>

                <Button onClick={addSoal} className="rounded-full bg-emerald-600 hover:bg-emerald-700">
                  <Plus className="w-4 h-4 mr-1" /> Tambah Soal
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Script Generator */}
          <TabsContent value="script" className="space-y-4 mt-4">
            <Card className="rounded-2xl border-0 shadow-soft">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-600" /> Script Generator
                </CardTitle>
                <p className="text-xs text-gray-500 mt-1">Tulis soal dengan format custom, sistem akan parse jadi soal otomatis</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-gray-50 rounded-xl p-4 text-xs text-gray-600 space-y-2">
                  <p className="font-semibold text-gray-700">Format Script:</p>
                  <pre className="text-xs whitespace-pre-wrap">{`## 1. isian          ← mulai tiap soal dengan ## dan nomor + jenis
P: Pertanyaan        ← teks pertanyaan (Indonesia)
AR: أَبٌ              ← (opsional) tampilkan Arabic RTL
Opsi: roti|nasi|air  ← (MCQ saja) opsi dipisah |
J: أَبٌ              ← jawaban benar (untuk MCQ, harus salah satu dari opsi)
Audio: https://...   ← (opsional) URL audio mp3
Gambar: https://...  ← (opsional) URL gambar
Video: https://...   ← (opsional) URL video (YouTube/upload)
Embed: https://...   ← (opsional) URL embed iframe
Fase: 1              ← (opsional) nomor fase (1, 2, 3...)
Kategori: Mufrodat   ← (opsional) kategori soal untuk evaluasi
Bobot: 1             ← (opsional) default 1

Jenis tersedia: isian, mcq`}</pre>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Script Soal</Label>
                  <Textarea
                    value={scriptText}
                    onChange={(e) => setScriptText(e.target.value)}
                    rows={16}
                    className="font-mono text-sm rounded-xl"
                    placeholder="## 1. isian
P: Tuliskan bahasa Arab: ayah
J: أَبٌ
Hint: cek audio"
                  />
                </div>

                <Button onClick={generateFromScript} disabled={generating} className="rounded-full bg-emerald-600 hover:bg-emerald-700">
                  {generating ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                      Sedang generate...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-1" /> Generate Soal dari Script
                    </>
                  )}
                </Button>
                {generateResult && (
                  <div className={`p-3 rounded-xl border ${generateResult.errors.length ? 'bg-amber-50 border-amber-200' : 'bg-emerald-50 border-emerald-200'}`}>
                    <div className="flex items-center gap-2 text-sm font-semibold">
                      <CheckCircle2 className={`w-4 h-4 ${generateResult.errors.length ? 'text-amber-600' : 'text-emerald-600'}`} />
                      <span className={generateResult.errors.length ? 'text-amber-800' : 'text-emerald-800'}>
                        {generateResult.created} soal berhasil dibuat
                      </span>
                    </div>
                    {generateResult.errors.length > 0 && (
                      <div className="mt-2 text-xs text-amber-700">
                        <p className="font-semibold mb-1">⚠️ {generateResult.errors.length} baris gagal:</p>
                        <ul className="list-disc list-inside space-y-0.5 max-h-32 overflow-y-auto font-mono">
                          {generateResult.errors.slice(0, 10).map((e, i) => (
                            <li key={i}>{e}</li>
                          ))}
                          {generateResult.errors.length > 10 && (
                            <li className="italic">...{generateResult.errors.length - 10} error lainnya</li>
                          )}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Hasil */}
          <TabsContent value="hasil" className="space-y-3 mt-4">
            {(!detailView.hasil || detailView.hasil.length === 0) ? (
              <Card className="rounded-2xl border-0 shadow-soft"><CardContent><EmptyState title="Belum ada hasil" /></CardContent></Card>
            ) : (
              <Card className="rounded-2xl border-0 shadow-soft">
                <CardContent className="p-0">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left py-3 px-4">Mahasiswa</th>
                        <th className="text-left py-3 px-4">Kamar</th>
                        <th className="text-left py-3 px-4">Status</th>
                        <th className="text-left py-3 px-4">Skor</th>
                        <th className="text-left py-3 px-4">Benar/Total</th>
                        <th className="text-left py-3 px-4">Selesai</th>
                      </tr>
                    </thead>
                    <tbody>
                      {detailView.hasil.map((h: any) => (
                        <tr key={h.id} className="border-b hover:bg-gray-50">
                          <td className="py-2 px-4 font-medium">{h.mahasiswa?.nama}</td>
                          <td className="py-2 px-4">{h.mahasiswa?.kamar?.nama}</td>
                          <td className="py-2 px-4"><Badge variant={h.status === 'graded' ? 'success' : h.status === 'submitted' ? 'info' : 'warning'}>{h.status}</Badge></td>
                          <td className="py-2 px-4 font-bold">{h.skorTotal?.toFixed(1)}%</td>
                          <td className="py-2 px-4">{h.jumlahBenar}/{h.jumlahSoal}</td>
                          <td className="py-2 px-4 text-gray-500 text-xs">{h.selesai ? new Date(h.selesai).toLocaleString('id-ID') : '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Tab Peserta */}
          <TabsContent value="peserta" className="space-y-4 mt-4">
            <PesertaTab sesi={detailView} onSaved={loadDetail} />
          </TabsContent>
        </Tabs>
      {/* Dialog Edit Soal — DIPINDAH ke sini (dalam detail view return) agar tombol Edit berfungsi */}
      <Dialog open={editSoalDialogOpen} onOpenChange={setEditSoalDialogOpen}>
        <DialogContent className="max-w-2xl rounded-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Soal #{editingSoal?.no}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Jenis</Label>
                <Select value={editSoalForm.jenis} onValueChange={(v) => setEditSoalForm({ ...editSoalForm, jenis: v })}>
                  <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="isian">Isian / Hafalan</SelectItem>
                    <SelectItem value="mcq">Pilihan Ganda (MCQ)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Materi (opsional)</Label>
                <Select value={editSoalForm.materiId || 'none'} onValueChange={(v) => setEditSoalForm({ ...editSoalForm, materiId: v === 'none' ? '' : v })}>
                  <SelectTrigger className="rounded-xl"><SelectValue placeholder="Tanpa materi" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Tanpa materi</SelectItem>
                    {materiList.map(m => <SelectItem key={m.id} value={m.id}>{m.arabic} — {m.arti}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Pertanyaan (Indonesia)</Label>
              <Textarea value={editSoalForm.pertanyaan} onChange={(e) => setEditSoalForm({ ...editSoalForm, pertanyaan: e.target.value })} rows={2} className="rounded-xl" />
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Pertanyaan Arabic (BUKAN jawaban - opsional)</Label>
              <Input value={editSoalForm.pertanyaanArabic} onChange={(e) => setEditSoalForm({ ...editSoalForm, pertanyaanArabic: e.target.value })} dir="rtl" className="font-arabic text-right text-xl rounded-xl" placeholder="مَا هَذَا؟" />
              <p className="text-xs text-amber-600">⚠️ Jangan isi dengan jawaban benar — ini akan terlihat oleh mahasiswa!</p>
            </div>
            {editSoalForm.jenis === 'mcq' && (
              <div className="space-y-2">
                <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Opsi (pilih jawaban benar dengan radio)</Label>
                {(editSoalForm.opsi || []).map((o: string, i: number) => (
                  <div key={i} className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="editJawabanBenarMCQ"
                      checked={editSoalForm.jawabanBenarIndex === i}
                      onChange={() => setEditSoalForm({ ...editSoalForm, jawabanBenarIndex: i, jawabanBenar: o })}
                      className="w-4 h-4 accent-emerald-600 flex-shrink-0"
                    />
                    <Input
                      value={o}
                      onChange={(e) => {
                        const newOpsi = [...editSoalForm.opsi]
                        newOpsi[i] = e.target.value
                        const newJawaban = editSoalForm.jawabanBenarIndex === i ? e.target.value : editSoalForm.jawabanBenar
                        setEditSoalForm({ ...editSoalForm, opsi: newOpsi, jawabanBenar: newJawaban })
                      }}
                      placeholder={`Opsi ${i + 1}`}
                      className={`rounded-xl flex-1 ${editSoalForm.jawabanBenarIndex === i ? 'border-emerald-400 bg-emerald-50/30' : ''}`}
                    />
                    {(editSoalForm.opsi || []).length > 2 && (
                      <button
                        onClick={() => {
                          const newOpsi = (editSoalForm.opsi || []).filter((_: string, idx: number) => idx !== i)
                          const newIndex = editSoalForm.jawabanBenarIndex >= i ? Math.max(0, editSoalForm.jawabanBenarIndex - 1) : editSoalForm.jawabanBenarIndex
                          setEditSoalForm({ ...editSoalForm, opsi: newOpsi, jawabanBenarIndex: newIndex, jawabanBenar: newOpsi[newIndex] || '' })
                        }}
                        className="text-rose-500 hover:text-rose-700 flex-shrink-0"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
                <Button size="sm" variant="outline" onClick={() => setEditSoalForm({ ...editSoalForm, opsi: [...(editSoalForm.opsi || []), ''] })} className="rounded-full">+ Tambah opsi</Button>
              </div>
            )}
            {editSoalForm.jenis === 'isian' && (
              <div className="space-y-2">
                <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Jawaban Benar</Label>
                <Input value={editSoalForm.jawabanBenar} onChange={(e) => setEditSoalForm({ ...editSoalForm, jawabanBenar: e.target.value })} dir="rtl" className="font-arabic text-right text-xl rounded-xl" />
              </div>
            )}
            {/* Media fields untuk Edit Soal */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 space-y-3">
              <p className="text-sm font-semibold text-blue-800 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" /> Media Soal (opsional)
              </p>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600 flex items-center gap-1">
                    <ImageIcon className="w-3 h-3" /> Image URL
                  </Label>
                  <Input value={editSoalForm.imageUrl} onChange={(e) => setEditSoalForm({ ...editSoalForm, imageUrl: e.target.value })} placeholder="https://...jpg" className="rounded-xl text-sm" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600 flex items-center gap-1">
                    <Video className="w-3 h-3" /> Video URL (YouTube/upload)
                  </Label>
                  <Input value={editSoalForm.videoUrl} onChange={(e) => setEditSoalForm({ ...editSoalForm, videoUrl: e.target.value })} placeholder="https://youtube.com/..." className="rounded-xl text-sm" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600 flex items-center gap-1">
                    <Music className="w-3 h-3" /> Audio URL (mp3)
                  </Label>
                  <Input value={editSoalForm.audioUrl} onChange={(e) => setEditSoalForm({ ...editSoalForm, audioUrl: e.target.value })} placeholder="https://...mp3" className="rounded-xl text-sm" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600 flex items-center gap-1">
                    <LinkIcon className="w-3 h-3" /> Embed URL (iframe)
                  </Label>
                  <Input value={editSoalForm.embedUrl} onChange={(e) => setEditSoalForm({ ...editSoalForm, embedUrl: e.target.value })} placeholder="https://..." className="rounded-xl text-sm" />
                </div>
              </div>
              {(editSoalForm.imageUrl || editSoalForm.audioUrl) && (
                <div className="mt-2 pt-2 border-t border-blue-200 space-y-2">
                  {editSoalForm.imageUrl && <img src={editSoalForm.imageUrl} alt="preview" className="max-h-32 rounded-lg border" />}
                  {editSoalForm.audioUrl && <audio controls src={editSoalForm.audioUrl} className="w-full h-9" preload="none" />}
                </div>
              )}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Bobot</Label>
                <Input type="number" step="0.5" value={editSoalForm.bobot} onChange={(e) => setEditSoalForm({ ...editSoalForm, bobot: parseFloat(e.target.value) || 1 })} className="rounded-xl" />
              </div>
            </div>
            {/* Fase & Kategori untuk Edit Soal */}
            <div className="bg-violet-50 border border-violet-200 rounded-xl p-4 space-y-3">
              <p className="text-sm font-semibold text-violet-800">Fase & Kategori (opsional)</p>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Fase</Label>
                  <Input
                    type="number"
                    value={editSoalForm.fase}
                    onChange={(e) => setEditSoalForm({ ...editSoalForm, fase: e.target.value })}
                    placeholder="Tanpa fase"
                    min="1"
                    className="rounded-xl"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Kategori</Label>
                  <Input
                    value={editSoalForm.kategori}
                    onChange={(e) => setEditSoalForm({ ...editSoalForm, kategori: e.target.value })}
                    placeholder="Mis. Mufrodat"
                    className="rounded-xl"
                  />
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditSoalDialogOpen(false)} className="rounded-xl">Batal</Button>
            <Button onClick={saveEditSoal} className="rounded-xl bg-emerald-600 hover:bg-emerald-700">Simpan Perubahan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Sesi Ujian"
        description={`${list.length} sesi terdaftar`}
        action={
          <Button onClick={openCreate} className="rounded-full bg-emerald-600 hover:bg-emerald-700">
            <Plus className="w-4 h-4 mr-1" /> Buat Sesi Ujian
          </Button>
        }
      />

      {list.length === 0 ? (
        <EmptyState title="Belum ada sesi ujian" description="Klik tombol di atas untuk membuat sesi pertama" />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {list.map(s => (
            <Card
              key={s.id}
              className={`cursor-pointer hover:shadow-md transition rounded-2xl border-0 shadow-soft ${s.aktif ? 'ring-2 ring-emerald-300' : ''}`}
              onClick={() => openDetail(s)}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-base">{s.nama}</CardTitle>
                    <p className="text-xs text-gray-500 mt-1">{s.level?.nama}</p>
                  </div>
                  <Badge variant={s.aktif ? 'success' : 'default'}>{s.aktif ? 'Aktif' : 'Selesai'}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex gap-3 text-xs text-gray-500 mb-3 flex-wrap">
                  <span><Badge variant="info">{s.mode}</Badge></span>
                  <span>{s.durasiMenit} menit</span>
                  <span>{s._count?.soal ?? 0} soal</span>
                  <span>{s._count?.hasil ?? 0} hasil</span>
                </div>
                {(s.acakUrutan || s.jumlahSoalPerMahasiswa) && (
                  <div className="mb-3 pt-3 border-t border-dashed border-gray-200 flex flex-wrap gap-1">
                    {s.acakUrutan && <Badge variant="purple"><Shuffle className="w-3 h-3 mr-1 inline" /> Acak</Badge>}
                    {s.jumlahSoalPerMahasiswa && <Badge variant="gold">{s.jumlahSoalPerMahasiswa}/mhs</Badge>}
                  </div>
                )}
                <p className="text-xs text-gray-400">{new Date(s.tanggalMulai).toLocaleString('id-ID')}</p>
                <div className="flex gap-2 mt-3" onClick={(e) => e.stopPropagation()}>
                  <Button size="sm" variant="outline" onClick={() => openEdit(s)} className="rounded-full">Edit</Button>
                  <Button size="sm" variant="ghost" className="text-rose-600 rounded-full" onClick={() => hapus(s.id)}>Hapus</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg rounded-2xl">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Sesi' : 'Buat Sesi Ujian'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-2">
              <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Nama Sesi</Label>
              <Input value={form.nama} onChange={(e) => setForm({ ...form, nama: e.target.value })} placeholder="Ujian Mufrodat Hari 1" className="rounded-xl" />
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Level</Label>
              <Select value={form.levelId} onValueChange={(v) => setForm({ ...form, levelId: v })}>
                <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {levelList.map(l => <SelectItem key={l.id} value={l.id}>{l.nama}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Mode</Label>
                <Select value={form.mode} onValueChange={(v) => setForm({ ...form, mode: v })}>
                  <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="online">Online (auto-koreksi)</SelectItem>
                    <SelectItem value="offline">Offline (penguji input)</SelectItem>
                    <SelectItem value="hybrid">Hybrid (gabungan)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Durasi (menit)</Label>
                <Input type="number" value={form.durasiMenit} onChange={(e) => setForm({ ...form, durasiMenit: parseInt(e.target.value) || 30 })} className="rounded-xl" />
              </div>
            </div>

            {/* Schedule: tanggal + jam mulai/selesai */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2">
                <Settings2 className="w-4 h-4 text-blue-600" />
                <p className="text-sm font-semibold text-blue-800">Waktu Pelaksanaan</p>
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium">Tanggal Pelaksanaan</Label>
                <Input
                  type="date"
                  value={form.tanggalMulai}
                  onChange={(e) => setForm({ ...form, tanggalMulai: e.target.value })}
                  className="rounded-xl"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Jam Mulai</Label>
                  <Input
                    type="time"
                    value={form.jamMulai}
                    onChange={(e) => setForm({ ...form, jamMulai: e.target.value })}
                    placeholder="08:00"
                    className="rounded-xl"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Jam Selesai</Label>
                  <Input
                    type="time"
                    value={form.jamSelesai}
                    onChange={(e) => setForm({ ...form, jamSelesai: e.target.value })}
                    placeholder="10:00"
                    className="rounded-xl"
                  />
                </div>
              </div>
            </div>

            {/* Randomization settings */}
            <div className="bg-violet-50 border border-violet-200 rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2">
                <Shuffle className="w-4 h-4 text-violet-600" />
                <p className="text-sm font-semibold text-violet-800">Pengaturan Acak (Anti-Contek)</p>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Acak urutan soal per mahasiswa</Label>
                  <p className="text-xs text-gray-500">Setiap mahasiswa dapat urutan soal berbeda</p>
                </div>
                <Switch checked={form.acakUrutan} onCheckedChange={(v) => setForm({ ...form, acakUrutan: v })} />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium">Ambil N soal random dari total</Label>
                <p className="text-xs text-gray-500">Kosongkan untuk ambil semua. Mis. isi 30 → tiap mahasiswa dapat 30 soal random dari total.</p>
                <Input
                  type="number"
                  value={form.jumlahSoalPerMahasiswa}
                  onChange={(e) => setForm({ ...form, jumlahSoalPerMahasiswa: e.target.value })}
                  placeholder="Mis. 30 (kosongkan untuk semua)"
                  className="rounded-xl"
                />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Switch checked={form.gunakanFase} onCheckedChange={(v) => setForm({ ...form, gunakanFase: v })} />
              <div>
                <Label>Bagi soal per Fase</Label>
                <p className="text-xs text-gray-500">Soal diacak per fase — fase 1 muncul dulu, lalu 2, dst</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Switch checked={form.aktif} onCheckedChange={(v) => setForm({ ...form, aktif: v })} />
              <Label>Aktif (mahasiswa bisa kerjakan)</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)} className="rounded-full">Batal</Button>
            <Button onClick={save} className="rounded-full bg-emerald-600 hover:bg-emerald-700">Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// PesertaTab — admin atur siapa yang berhak ikut ujian
function PesertaTab({ sesi, onSaved }: { sesi: any; onSaved: () => void }) {
  const [allMhs, setAllMhs] = useState<any[]>([])
  const [selectedNims, setSelectedNims] = useState<string[]>([])
  const [allowAll, setAllowAll] = useState(true)
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => {
    Promise.all([
      fetch('/api/mahasiswa').then(r => r.json()),
    ]).then(([mhsData]) => {
      setAllMhs(mhsData.data || [])
      // Load existing pesertaJson
      if (sesi.pesertaJson) {
        try {
          const arr = JSON.parse(sesi.pesertaJson)
          if (Array.isArray(arr) && arr.length > 0) {
            setSelectedNims(arr)
            setAllowAll(false)
          }
        } catch {}
      }
      setLoading(false)
    })
  }, [sesi.id])

  function toggleNim(nim: string) {
    setSelectedNims(prev =>
      prev.includes(nim) ? prev.filter(n => n !== nim) : [...prev, nim]
    )
    setAllowAll(false)
  }

  function toggleAll() {
    if (allowAll) {
      setAllowAll(false)
      setSelectedNims([])
    } else {
      setAllowAll(true)
      setSelectedNims([])
    }
  }

  function selectUnfinished() {
    // Centang mahasiswa yang belum mengikuti ujian
    const finishedNims = new Set((sesi.hasil || []).map((h: any) => h.mahasiswa?.nim).filter(Boolean))
    const unfinished = allMhs.filter(m => !finishedNims.has(m.nim)).map(m => m.nim)
    setSelectedNims(unfinished)
    setAllowAll(false)
  }

  async function savePeserta() {
    const pesertaJson = allowAll ? null : JSON.stringify(selectedNims)
    const res = await fetch('/api/sesi', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'save-peserta', sesiId: sesi.id, pesertaJson }),
    })
    if (res.ok) {
      toast({ title: 'Peserta tersimpan', description: allowAll ? 'Semua mahasiswa diizinkan' : `${selectedNims.length} mahasiswa dipilih` })
      onSaved()
    }
  }

  const filteredMhs = allMhs.filter(m =>
    !search ||
    m.nama.toLowerCase().includes(search.toLowerCase()) ||
    m.nim.includes(search)
  )

  if (loading) return <Loading />

  return (
    <Card className="rounded-2xl border border-gray-200 shadow-soft">
      <CardHeader>
        <CardTitle className="text-base">Peserta Ujian</CardTitle>
        <p className="text-xs text-gray-500">Pilih siapa saja yang berhak mengikuti ujian ini</p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Mode toggle */}
        <div className="flex items-center gap-2 p-3 bg-blue-50 border border-blue-200 rounded-xl">
          <input
            type="checkbox"
            checked={allowAll}
            onChange={toggleAll}
            className="w-5 h-5 rounded"
          />
          <span className="text-sm font-semibold text-blue-800">Izinkan semua mahasiswa</span>
        </div>

        {/* Quick actions */}
        {!allowAll && (
          <div className="flex gap-2 flex-wrap">
            <Button size="sm" variant="outline" onClick={selectUnfinished} className="rounded-xl">
              Centang yang Belum Ikut
            </Button>
            <Button size="sm" variant="outline" onClick={() => { setSelectedNims(allMhs.map(m => m.nim)); setAllowAll(false) }} className="rounded-xl">
              Centang Semua
            </Button>
            <Button size="sm" variant="ghost" onClick={() => { setSelectedNims([]); setAllowAll(false) }} className="rounded-xl text-rose-600">
              Kosongkan
            </Button>
            <span className="text-xs text-gray-500 self-center ml-auto">{selectedNims.length} dari {allMhs.length} dipilih</span>
          </div>
        )}

        {/* Mahasiswa list */}
        {!allowAll && (
          <>
            <Input
              placeholder="Cari nama/NIM..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="rounded-xl max-w-xs"
            />
            <div className="max-h-96 overflow-y-auto scroll-thin border border-gray-200 rounded-xl">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 sticky top-0">
                  <tr>
                    <th className="text-left py-2 px-3 w-10"></th>
                    <th className="text-left py-2 px-3">NIM</th>
                    <th className="text-left py-2 px-3">Nama</th>
                    <th className="text-left py-2 px-3">Kamar</th>
                    <th className="text-left py-2 px-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredMhs.map(m => {
                    const hasHasil = (sesi.hasil || []).some((h: any) => h.mahasiswaId === m.id)
                    return (
                      <tr key={m.id} className="border-b hover:bg-gray-50 cursor-pointer" onClick={() => toggleNim(m.nim)}>
                        <td className="py-2 px-3">
                          <input
                            type="checkbox"
                            checked={selectedNims.includes(m.nim)}
                            onChange={() => toggleNim(m.nim)}
                            className="w-4 h-4 rounded"
                          />
                        </td>
                        <td className="py-2 px-3 font-mono">{m.nim}</td>
                        <td className="py-2 px-3">{m.nama}</td>
                        <td className="py-2 px-3">{m.kamar?.nama}</td>
                        <td className="py-2 px-3">
                          {hasHasil ? <Badge variant="success">Sudah</Badge> : <Badge variant="default">Belum</Badge>}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}

        <Button onClick={savePeserta} className="rounded-xl bg-emerald-600 hover:bg-emerald-700">
          Simpan Peserta
        </Button>
      </CardContent>
    </Card>
  )
}
