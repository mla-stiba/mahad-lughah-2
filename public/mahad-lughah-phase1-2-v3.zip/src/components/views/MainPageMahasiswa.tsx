'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge, EmptyState, Loading, PageHeader } from '@/components/shared'
import { ArabicText } from '@/components/shared'
import { FileText, Clock, ArrowRight, BookOpen, Sparkles } from 'lucide-react'
import Link from 'next/link'

export function MainPageMahasiswa({ session }: { session: any }) {
  const [loading, setLoading] = useState(true)
  const [latestMateri, setLatestMateri] = useState<any[]>([])
  const [latestHasil, setLatestHasil] = useState<any[]>([])

  useEffect(() => {
    Promise.all([
      fetch('/api/materi-mahasiswa').then(r => r.json()),
      fetch(`/api/hasil?action=by-mahasiswa&mahasiswaId=${session.mahasiswa.id}`).then(r => r.json()),
    ]).then(async ([matR, hasilR]) => {
      const materi = (matR.data || []).slice(0, 5)
      setLatestMateri(materi)
      setLatestHasil((hasilR.data || []).slice(0, 5))
      setLoading(false)
      // Record view event untuk semua materi yang ditampilkan di beranda
      // (asumsi: user yang buka beranda = sudah lihat materi)
      // Penting untuk fitur #4: tracking anggota yang sudah lihat materi hari ini
      if (materi.length > 0) {
        Promise.all(materi.map(m =>
          fetch('/api/tracking?action=view-materi', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ mahasiswaId: session.mahasiswa.id, materiId: m.id }),
          }).catch(() => {}) // fail-safe: kalau tabel belum migrate, skip
        ))
      }
    })
  }, [])

  if (loading) return <Loading />

  return (
    <div className="space-y-6">
      {/* Welcome header */}
      <div className="bg-gradient-to-br from-[oklch(0.35_0.14_265)] to-[oklch(0.25_0.06_265)] text-white rounded-2xl p-6 relative overflow-hidden">
        <div className="absolute -top-8 -right-8 w-40 h-40 rounded-full bg-amber-400/20 blur-3xl" />
        <h1 className="text-2xl font-bold font-display">Assalamualaikum, {session.mahasiswa?.nama}!</h1>
        <p className="text-white/80 text-sm mt-1">Selamat datang di Ma'had Lughah</p>
        <div className="flex gap-3 mt-4">
          <Badge variant="info">{session.mahasiswa?.nim}</Badge>
          <span className="text-white/70 text-sm">{session.mahasiswa?.kamar?.nama}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Latest Ujian */}
        <Card className="rounded-2xl border border-gray-200 shadow-soft">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-600" /> Ujian Terakhir
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {latestHasil.length === 0 ? (
              <EmptyState title="Belum ada ujian dikerjakan" />
            ) : (
              latestHasil.map(h => {
                const skor = h.skorTotal || 0
                const grade = getGradeColor(skor)
                return (
                  <div key={h.id} className="flex items-center justify-between p-3 border rounded-xl hover:bg-gray-50">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{h.sesi?.nama}</p>
                      <p className="text-xs text-gray-500 mt-0.5">
                        {h.selesai ? new Date(h.selesai).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }) : '-'}
                      </p>
                    </div>
                    <div className="text-right ml-2">
                      <p className={`text-lg font-bold ${grade}`}>{skor.toFixed(0)}%</p>
                      <p className="text-xs text-gray-400">{h.jumlahBenar}/{h.jumlahSoal}</p>
                    </div>
                  </div>
                )
              })
            )}
          </CardContent>
        </Card>

        {/* Latest Materi — di-urutkan dari API tanggalRilis DESC, paling baru di atas */}
        <Card className="rounded-2xl border border-gray-200 shadow-soft">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-emerald-600" /> Materi Terbaru
              <Badge variant="success" className="text-[10px]"><Sparkles className="w-2.5 h-2.5 mr-0.5" /> Live</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {latestMateri.length === 0 ? (
              <EmptyState title="Belum ada materi dirilis" description="Materi yang sudah dijadwalkan akan muncul di sini" />
            ) : (
              latestMateri.map(m => {
                const isToday = m.tanggalRilis && isTodayDate(new Date(m.tanggalRilis))
                const isYesterday = m.tanggalRilis && isYesterdayDate(new Date(m.tanggalRilis))
                return (
                  <div key={m.id} className={`p-3 border rounded-xl hover:bg-gray-50 ${isToday ? 'border-emerald-300 bg-emerald-50/30' : ''}`}>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant={m.jenis === 'mufrodat' ? 'info' : 'warning'}>{m.jenis}</Badge>
                          {m.kategori && <span className="text-xs text-gray-400">{m.kategori}</span>}
                          {isToday && (
                            <Badge variant="success" className="text-[10px] ml-auto">
                              <Sparkles className="w-2.5 h-2.5 mr-0.5" />
                              BARU HARI INI
                            </Badge>
                          )}
                          {isYesterday && (
                            <span className="text-[10px] text-gray-500 ml-auto">Kemarin</span>
                          )}
                        </div>
                        <div className="text-right mb-1">
                          <ArabicText size="md" className="text-gray-900">{m.arabic}</ArabicText>
                        </div>
                        <p className="text-sm font-medium">{m.arti}</p>
                      </div>
                      {m.tanggalRilis && (
                        <span className="text-xs text-gray-400 flex items-center gap-1 flex-shrink-0">
                          <Clock className="w-3 h-3" />
                          {isToday ? 'Hari ini' : isYesterday ? 'Kemarin' : new Date(m.tanggalRilis).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}
                        </span>
                      )}
                    </div>
                    {/* Media preview */}
                    {m.imageUrl && (
                      <img src={m.imageUrl} alt={m.arti} className="w-full max-h-32 object-cover rounded-lg mt-2" />
                    )}
                    {m.audioUrl && (
                      <audio controls src={m.audioUrl} className="w-full h-8 mt-2" preload="none" />
                    )}
                    {m.contoh && (
                      <div className="text-right mt-2 bg-gray-50 rounded p-2">
                        <ArabicText size="sm" className="text-gray-600">{m.contoh}</ArabicText>
                      </div>
                    )}
                  </div>
                )
              })
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function getGradeColor(skor: number): string {
  if (skor >= 90) return 'text-emerald-600'
  if (skor >= 80) return 'text-blue-600'
  if (skor >= 65) return 'text-amber-600'
  if (skor >= 50) return 'text-orange-600'
  return 'text-rose-600'
}

// Helper: cek apakah tanggal = hari ini
function isTodayDate(date: Date): boolean {
  const today = new Date()
  return (
    date.getDate() === today.getDate() &&
    date.getMonth() === today.getMonth() &&
    date.getFullYear() === today.getFullYear()
  )
}

// Helper: cek apakah tanggal = kemarin
function isYesterdayDate(date: Date): boolean {
  const yesterday = new Date()
  yesterday.setDate(yesterday.getDate() - 1)
  return (
    date.getDate() === yesterday.getDate() &&
    date.getMonth() === yesterday.getMonth() &&
    date.getFullYear() === yesterday.getFullYear()
  )
}
