'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart3 } from 'recharts'
import { toast } from '@/hooks/use-toast'
import { ArabicText, EmptyState, Loading, Badge, PageHeader } from '@/components/shared'
import { getGrade } from '@/components/shared/grade'

export function HasilView() {
  const [loading, setLoading] = useState(true)
  const [sesiList, setSesiList] = useState<any[]>([])
  const [selectedSesi, setSelectedSesi] = useState<string>('')
  const [allHasil, setAllHasil] = useState<any[]>([])
  const [byMateri, setByMateri] = useState<any[]>([])
  const [crossTab, setCrossTab] = useState<any>(null)
  const [searchMhs, setSearchMhs] = useState('')

  async function load() {
    setLoading(true)
    const sl = await fetch('/api/sesi').then(r => r.json())
    setSesiList(sl.data || [])
    if (sl.data && sl.data.length > 0 && !selectedSesi) {
      setSelectedSesi(sl.data[0].id)
    }
    setLoading(false)
  }

  async function loadData() {
    if (!selectedSesi) return
    setLoading(true)
    const [all, bm, ct] = await Promise.all([
      fetch(`/api/hasil?action=all&sesiId=${selectedSesi}`).then(r => r.json()),
      fetch(`/api/hasil?action=by-materi&sesiId=${selectedSesi}`).then(r => r.json()),
      fetch(`/api/hasil?action=cross-tab&sesiId=${selectedSesi}`).then(r => r.json()),
    ])
    setAllHasil(all.data || [])
    setByMateri(bm.data || [])
    setCrossTab(ct.data)
    setLoading(false)
  }

  useEffect(() => { load() }, [])
  useEffect(() => { if (selectedSesi) loadData() }, [selectedSesi])

  function exportCSV() {
    if (allHasil.length === 0) {
      toast({ title: 'Tidak ada data untuk di-export', variant: 'destructive' })
      return
    }
    const rows = [
      ['Nama', 'Kamar', 'Skor', 'Benar', 'Total Soal', 'Status', 'Selesai'],
      ...allHasil.map(h => [
        h.mahasiswa?.nama || '',
        h.mahasiswa?.kamar?.nama || '',
        h.skorTotal?.toFixed(1) || '0',
        String(h.jumlahBenar || 0),
        String(h.jumlahSoal || 0),
        h.status,
        h.selesai ? new Date(h.selesai).toLocaleString('id-ID') : '-',
      ]),
    ]
    const csv = rows.map(r => r.map(c => `"${c}"`).join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `hasil-${selectedSesi}.csv`
    a.click()
    URL.revokeObjectURL(url)
    toast({ title: 'CSV diunduh' })
  }

  function printReport() {
    window.print()
  }

  if (loading) return <Loading />

  const filteredHasil = allHasil.filter(h =>
    !searchMhs ||
    h.mahasiswa?.nama.toLowerCase().includes(searchMhs.toLowerCase()) ||
    h.mahasiswa?.kode.toLowerCase().includes(searchMhs.toLowerCase())
  )

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Hasil &amp; Evaluasi</h2>
          <p className="text-sm text-gray-500 mt-1">Analisis hasil ujian</p>
        </div>
        <div className="flex gap-3 items-center no-print">
          <Select value={selectedSesi} onValueChange={setSelectedSesi}>
            <SelectTrigger className="w-72"><SelectValue placeholder="Pilih sesi" /></SelectTrigger>
            <SelectContent>
              {sesiList.map(s => <SelectItem key={s.id} value={s.id}>{s.nama}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={exportCSV}>Export CSV</Button>
          <Button variant="outline" onClick={printReport}>Print</Button>
        </div>
      </div>

      {!selectedSesi ? (
        <EmptyState title="Pilih sesi ujian dulu" />
      ) : (
        <Tabs defaultValue="all">
          <TabsList className="no-print">
            <TabsTrigger value="all">Semua Hasil ({allHasil.length})</TabsTrigger>
            <TabsTrigger value="per-materi">Per Materi</TabsTrigger>
            <TabsTrigger value="cross-tab">Cross-Tab (Kamar × Materi)</TabsTrigger>
          </TabsList>

          {/* Tab: All hasil */}
          <TabsContent value="all" className="space-y-4">
            <Input placeholder="Cari nama/kode mahasiswa..." value={searchMhs} onChange={(e) => setSearchMhs(e.target.value)} className="max-w-xs no-print" />

            <Card>
              <CardContent className="p-0">
                {filteredHasil.length === 0 ? (
                  <EmptyState title="Belum ada hasil" />
                ) : (
                  <div className="overflow-x-auto scroll-thin max-h-[600px] overflow-y-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-gray-50 sticky top-0">
                        <tr>
                          <th className="text-left py-2 px-3">Kode</th>
                          <th className="text-left py-2 px-3">Nama</th>
                          <th className="text-left py-2 px-3">Kamar</th>
                          <th className="text-left py-2 px-3">Status</th>
                          <th className="text-left py-2 px-3">Skor</th>
                          <th className="text-left py-2 px-3">Benar/Total</th>
                          <th className="text-left py-2 px-3">Selesai</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredHasil.sort((a, b) => (b.skorTotal || 0) - (a.skorTotal || 0)).map(h => (
                          <tr key={h.id} className="border-b hover:bg-gray-50">
                            <td className="py-2 px-3"><Badge variant="info">{h.mahasiswa?.kode}</Badge></td>
                            <td className="py-2 px-3 font-medium">{h.mahasiswa?.nama}</td>
                            <td className="py-2 px-3">{h.mahasiswa?.kamar?.nama}</td>
                            <td className="py-2 px-3"><Badge variant={h.status === 'graded' ? 'success' : h.status === 'submitted' ? 'info' : 'warning'}>{h.status}</Badge></td>
                            <td className="py-2 px-3">
                              {(() => {
                                const skor = h.skorTotal || 0
                                const grade = getGrade(skor)
                                return (
                                  <div className="flex flex-col gap-0.5">
                                    <span className={`font-bold ${grade.color}`}>{skor.toFixed(1)}%</span>
                                    <span className={`font-arabic text-sm ${grade.color}`}>{grade.arabic}</span>
                                  </div>
                                )
                              })()}
                            </td>
                            <td className="py-2 px-3">{h.jumlahBenar || 0}/{h.jumlahSoal || 0}</td>
                            <td className="py-2 px-3 text-gray-500 text-xs">{h.selesai ? new Date(h.selesai).toLocaleString('id-ID') : '-'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Per-materi item analysis */}
          <TabsContent value="per-materi" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Item Analysis — Tingkat Kesulitan Soal</CardTitle>
              </CardHeader>
              <CardContent>
                {byMateri.length === 0 ? (
                  <EmptyState title="Belum ada data" />
                ) : (
                  <>
                    <ResponsiveContainer width="100%" height={400}>
                      <BarChart data={byMateri} layout="vertical" margin={{ left: 200 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
                        <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11 }} unit="%" />
                        <YAxis type="category" dataKey="no" tick={{ fontSize: 11 }} tickFormatter={(v) => `#${v}`} />
                        <Tooltip
                          formatter={(v: any) => [`${Number(v).toFixed(1)}%`, 'Akurasi']}
                          labelFormatter={(label: any, payload: any) => {
                            const item = payload?.[0]?.payload
                            return item ? `Soal #${item.no}: ${item.pertanyaan?.slice(0, 60)}...` : `Soal #${label}`
                          }}
                        />
                        <Bar dataKey="accuracy" fill="#0284c7" radius={[0, 4, 4, 0]} />
                      </BarChart>
                    </ResponsiveContainer>

                    <div className="mt-6 overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="text-left py-2 px-3">#</th>
                            <th className="text-right py-2 px-3">Pertanyaan Arabic</th>
                            <th className="text-left py-2 px-3">Pertanyaan</th>
                            <th className="text-left py-2 px-3">Benar</th>
                            <th className="text-left py-2 px-3">Total</th>
                            <th className="text-left py-2 px-3">Akurasi</th>
                            <th className="text-left py-2 px-3">Tingkat</th>
                          </tr>
                        </thead>
                        <tbody>
                          {byMateri.map(m => (
                            <tr key={m.id} className="border-b hover:bg-gray-50">
                              <td className="py-2 px-3">#{m.no}</td>
                              <td className="py-2 px-3 text-right">
                                {m.arabic && <ArabicText size="md" className="text-emerald-700">{m.arabic}</ArabicText>}
                              </td>
                              <td className="py-2 px-3 text-xs text-gray-600 max-w-xs truncate">{m.pertanyaan}</td>
                              <td className="py-2 px-3 text-emerald-700 font-medium">{m.benar}</td>
                              <td className="py-2 px-3">{m.total}</td>
                              <td className="py-2 px-3 font-bold">{m.accuracy.toFixed(1)}%</td>
                              <td className="py-2 px-3">
                                <Badge variant={m.accuracy >= 80 ? 'success' : m.accuracy >= 60 ? 'warning' : 'danger'}>
                                  {m.accuracy >= 80 ? 'Mudah' : m.accuracy >= 60 ? 'Sedang' : 'Sulit'}
                                </Badge>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Cross-tab heatmap */}
          <TabsContent value="cross-tab" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Heatmap Kamar × Soal</CardTitle>
                <p className="text-xs text-gray-500 mt-1">Akurasi (%) per kamar per soal. Sel merah = banyak yang salah, hijau = banyak yang benar.</p>
              </CardHeader>
              <CardContent>
                {!crossTab || !crossTab.matrix || crossTab.matrix.length === 0 ? (
                  <EmptyState title="Belum ada data cross-tab" />
                ) : (
                  <div className="overflow-x-auto">
                    <table className="border-collapse text-sm">
                      <thead>
                        <tr>
                          <th className="border border-gray-300 p-2 sticky left-0 bg-white">Kamar</th>
                          {crossTab.soal.map((s: any) => (
                            <th key={s.id} className="border border-gray-300 p-2 min-w-[120px]">
                              <div className="text-center">
                                <div className="text-xs text-gray-500">#{s.no}</div>
                                {s.arabic && (
                                  <div className="my-1">
                                    <ArabicText size="sm" className="text-emerald-700">{s.arabic}</ArabicText>
                                  </div>
                                )}
                                {s.arti && <div className="text-xs text-gray-400">{s.arti}</div>}
                              </div>
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {crossTab.matrix.map((row: any) => (
                          <tr key={row.kamarId}>
                            <td className="border border-gray-300 p-2 font-medium bg-gray-50 sticky left-0">{row.kamarNama}</td>
                            {crossTab.soal.map((s: any) => {
                              const cell = row.cells[s.id]
                              if (!cell) {
                                return <td key={s.id} className="border border-gray-300 p-2 text-center text-gray-300">-</td>
                              }
                              const acc = cell.accuracy
                              const bgColor = acc >= 80 ? 'bg-emerald-100 text-emerald-800'
                                : acc >= 60 ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                              return (
                                <td key={s.id} className={`border border-gray-300 p-2 text-center ${bgColor}`}>
                                  <div className="font-bold">{acc.toFixed(0)}%</div>
                                  <div className="text-xs">{cell.benar}/{cell.total}</div>
                                </td>
                              )
                            })}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}
