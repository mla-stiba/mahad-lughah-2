'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge, EmptyState, Loading } from '@/components/shared'
import { ArabicText } from '@/components/shared'
import { Clock, BookOpen } from 'lucide-react'

export function MateriMahasiswaView({ session }: { session: any }) {
  const [loading, setLoading] = useState(true)
  const [materi, setMateri] = useState<any[]>([])
  const [filterJenis, setFilterJenis] = useState('all')

  useEffect(() => {
    fetch('/api/materi-mahasiswa').then(r => r.json()).then(d => {
      setMateri(d.data || [])
      setLoading(false)
    })
  }, [])

  if (loading) return <Loading />

  const filtered = filterJenis === 'all' ? materi : materi.filter(m => m.jenis === filterJenis)

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Materi</h2>
        <p className="text-sm text-gray-500 mt-1">Materi yang sudah dirilis</p>
      </div>

      {/* Filter */}
      <div className="flex gap-2">
        {['all', 'mufrodat', 'tarkib'].map(j => (
          <button
            key={j}
            onClick={() => setFilterJenis(j)}
            className={`px-3 py-1.5 rounded-xl text-sm font-medium ${filterJenis === j ? 'bg-[oklch(0.50_0.18_265)] text-white' : 'bg-gray-100 text-gray-600'}`}
          >
            {j === 'all' ? 'Semua' : j === 'mufrodat' ? 'Mufrodat' : 'Tarkib'}
          </button>
        ))}
      </div>

      {/* Materi cards (post-style) */}
      {filtered.length === 0 ? (
        <EmptyState title="Belum ada materi dirilis" description="Materi akan muncul di sini setelah dirilis oleh admin" />
      ) : (
        <div className="space-y-4">
          {filtered.map(m => (
            <Card key={m.id} className="rounded-2xl border border-gray-200 shadow-soft overflow-hidden">
              {/* Header: jenis + tanggal rilis */}
              <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border-b">
                <div className="flex items-center gap-2">
                  <Badge variant={m.jenis === 'mufrodat' ? 'info' : 'warning'}>{m.jenis}</Badge>
                  {m.kategori && <span className="text-xs text-gray-500">{m.kategori}</span>}
                </div>
                {m.tanggalRilis && (
                  <span className="text-xs text-gray-400 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {new Date(m.tanggalRilis).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}
                  </span>
                )}
              </div>

              <CardContent className="p-4 space-y-3">
                {/* Arabic */}
                <div className="text-right py-2">
                  <ArabicText size="xl" className="text-gray-900">{m.arabic}</ArabicText>
                </div>

                {/* Arti */}
                <p className="font-semibold text-lg text-gray-800">{m.arti}</p>

                {/* Contoh */}
                {m.contoh && (
                  <div className="text-right bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-400 mb-1">Contoh:</p>
                    <ArabicText size="md" className="text-gray-600">{m.contoh}</ArabicText>
                  </div>
                )}

                {/* Media */}
                {m.imageUrl && (
                  <img src={m.imageUrl} alt={m.arti} className="w-full max-h-60 object-cover rounded-lg" />
                )}
                {m.videoUrl && (
                  <div className="rounded-lg overflow-hidden">
                    {m.videoUrl.includes('youtube.com') || m.videoUrl.includes('youtu.be') ? (
                      <iframe
                        src={m.videoUrl.includes('embed') ? m.videoUrl : `https://www.youtube.com/embed/${(m.videoUrl.match(/[?&]v=([^&]+)/) || m.videoUrl.match(/youtu\.be\/([^?]+)/) || ['',''])[1]}`}
                        className="w-full aspect-video"
                        allowFullScreen
                      />
                    ) : (
                      <video controls src={m.videoUrl} className="w-full max-h-60" preload="metadata" />
                    )}
                  </div>
                )}
                {m.audioUrl && (
                  <audio controls src={m.audioUrl} className="w-full" preload="metadata" />
                )}
                {m.externalLink && (
                  <a href={m.externalLink} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-sm text-blue-600 hover:underline">
                    📎 Referensi eksternal
                  </a>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
