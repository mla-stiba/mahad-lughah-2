'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { toast } from '@/hooks/use-toast'
import { openWhatsAppShare, formatEvaluasiKamarMessage } from '@/lib/wa-share'
import { ArabicText, EmptyState, Loading, Badge, PageHeader } from '@/components/shared'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Check, X, AlertTriangle, Users, BookOpen, Share2, Loader2 } from 'lucide-react'

interface KetuaKamarViewProps {
  session: any
}

// ============ KETUA KAMAR VIEW ============
// Tampil untuk mahasiswa dengan isKetuaKamar = true.
// Berisi 3 tab:
// 1. Anggota Kamar: list anggota + status login hari ini + tombol ingatkan WA
// 2. Monitoring Hafalan: grid anggota x materi dengan checkbox
// 3. Belum Lihat Materi: list materi baru + anggota yang belum view

export function KetuaKamarView({ session }: KetuaKamarViewProps) {
  const [activeTab, setActiveTab] = useState('anggota')

  // ===== DATA ANGGOTA KAMAR =====
  const [kamarData, setKamarData] = useState<any>(null)
  const [loadingKamar, setLoadingKamar] = useState(true)
  const [notifSent, setNotifSent] = useState<Set<string>>(new Set()) // nim yang sudah diingatkan

  async function loadKamarStatus() {
    if (!session.mahasiswa?.kamar?.id) return
    setLoadingKamar(true)
    try {
      const r = await fetch(`/api/tracking?action=kamar-status&kamarId=${session.mahasiswa.kamar.id}`).then(r => r.json())
      setKamarData(r.data)
    } catch (e: any) {
      toast({ title: 'Gagal load data kamar', description: e.message, variant: 'destructive' })
    }
    setLoadingKamar(false)
  }

  useEffect(() => { loadKamarStatus() }, [])

  // ===== DATA HAFALAN =====
  const [hafalanGrid, setHafalanGrid] = useState<any[]>([])
  const [materiList, setMateriList] = useState<any[]>([])
  const [loadingHafalan, setLoadingHafalan] = useState(true)
  const [filterLevel, setFilterLevel] = useState('all')

  async function loadHafalanGrid() {
    if (!session.mahasiswa?.kamar?.id) return
    setLoadingHafalan(true)
    try {
      const r = await fetch(`/api/hafalan?kamarId=${session.mahasiswa.kamar.id}&levelId=${filterLevel}`).then(r => r.json())
      setHafalanGrid(r.data || [])
      setMateriList(r.materiList || [])
    } catch (e: any) {
      toast({ title: 'Gagal load data hafalan', description: e.message, variant: 'destructive' })
    }
    setLoadingHafalan(false)
  }

  useEffect(() => { loadHafalanGrid() }, [filterLevel])

  async function updateHafalan(mahasiswaId: string, materiId: string, status: string) {
    // Optimistic update
    setHafalanGrid(prev => prev.map(row => {
      if (row.mahasiswa.id !== mahasiswaId) return row
      return {
        ...row,
        materi: row.materi.map((m: any) => m.materi.id === materiId ? { ...m, status } : m),
      }
    }))
    try {
      await fetch('/api/hafalan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mahasiswaId, materiId, status,
          centangBy: session.mahasiswa.nama,
        }),
      })
    } catch (e: any) {
      toast({ title: 'Gagal update status', description: e.message, variant: 'destructive' })
      loadHafalanGrid() // rollback
    }
  }

  // ===== DATA BELUM LIHAT MATERI =====
  const [belumViewData, setBelumViewData] = useState<any[]>([])
  const [loadingBelumView, setLoadingBelumView] = useState(true)

  async function loadBelumViewMateri() {
    setLoadingBelumView(true)
    try {
      const r = await fetch('/api/tracking?action=belum-view-materi-hari-ini').then(r => r.json())
      // Filter hanya anggota kamar ketua
      const kamarId = session.mahasiswa?.kamar?.id
      const filtered = (r.data || []).map((item: any) => ({
        ...item,
        belumView: item.belumView.filter((m: any) => m.kamar?.id === kamarId || m.kamar?.nama === session.mahasiswa?.kamar?.nama),
      })).filter((item: any) => item.belumView.length > 0)
      setBelumViewData(filtered)
    } catch (e: any) {
      toast({ title: 'Gagal load data', description: e.message, variant: 'destructive' })
    }
    setLoadingBelumView(false)
  }

  useEffect(() => { loadBelumViewMateri() }, [])

  // ===== WHATSAPP SHARE =====
  function ingatkanWA(nama: string, nim: string, wa: string | null, pesan: string) {
    openWhatsAppShare(wa, pesan)
    setNotifSent(prev => new Set(prev).add(nim))
    toast({ title: `Notifikasi untuk ${nama} disiapkan`, description: wa ? 'Membuka WhatsApp...' : 'Pilih kontak di WhatsApp' })
  }

  function shareEvaluasiSemua() {
    if (!kamarData) return
    const anggota = kamarData.anggota.map((a: any) => ({
      nama: a.nama,
      nim: a.nim,
      skor: 0, // TODO: ambil dari hasil ujian terakhir
      status: a.loginToday ? 'Sudah login hari ini' : 'Belum login hari ini',
    }))
    const message = formatEvaluasiKamarMessage({
      ketuaNama: session.mahasiswa.nama,
      kamarNama: kamarData.kamar.nama,
      anggota,
      appUrl: typeof window !== 'undefined' ? window.location.origin : undefined,
    })
    openWhatsAppShare(null, message) // pilih grup kamar di WA
    toast({ title: 'Evaluasi kamar disiapkan untuk share ke grup' })
  }

  if (!session.mahasiswa?.isKetuaKamar) {
    return <EmptyState title="Bukan ketua kamar" description="Halaman ini khusus untuk ketua kamar" />
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Monitoring Kamar"
        description={`Ketua Kamar ${kamarData?.kamar?.nama || ''}`}
        action={
          <Button onClick={shareEvaluasiSemua} variant="outline" className="rounded-xl bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100">
            <Share2 className="w-4 h-4 mr-1.5" />
            Share Evaluasi ke Grup
          </Button>
        }
      />

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-gray-100 rounded-xl p-1 h-10">
          <TabsTrigger value="anggota" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm text-sm">
            <Users className="w-4 h-4 mr-1 inline" /> Anggota
          </TabsTrigger>
          <TabsTrigger value="hafalan" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm text-sm">
            <BookOpen className="w-4 h-4 mr-1 inline" /> Hafalan
          </TabsTrigger>
          <TabsTrigger value="belum-view" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm text-sm">
            <AlertTriangle className="w-4 h-4 mr-1 inline" /> Belum Lihat
          </TabsTrigger>
        </TabsList>

        {/* ===== TAB: ANGGOTA KAMAR ===== */}
        <TabsContent value="anggota" className="space-y-4 mt-4">
          {loadingKamar ? <Loading /> : !kamarData ? (
            <EmptyState title="Data kamar tidak ditemukan" />
          ) : (
            <Card className="rounded-2xl border border-gray-200 shadow-soft">
              <CardHeader>
                <CardTitle className="text-base flex items-center justify-between">
                  <span>Anggota Kamar {kamarData.kamar.nama}</span>
                  <Badge variant="info">{kamarData.anggota.length} anggota</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y divide-gray-100">
                  {kamarData.anggota.map((a: any) => (
                    <div key={a.id} className="flex items-center justify-between p-4 hover:bg-gray-50">
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${a.loginToday ? 'bg-emerald-500' : 'bg-rose-400'}`} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="font-medium text-sm truncate">{a.nama}</p>
                            {a.isKetuaKamar && <Badge variant="gold" className="text-[10px]">Ketua</Badge>}
                          </div>
                          <p className="text-xs text-gray-500 mt-0.5">
                            {a.loginToday
                              ? `Sudah login hari ini${a.lastLogin ? ' · ' + new Date(a.lastLogin).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) : ''}`
                              : 'Belum login hari ini'}
                          </p>
                        </div>
                      </div>
                      {!a.loginToday && !a.isKetuaKamar && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="rounded-lg bg-rose-50 border-rose-200 text-rose-700 hover:bg-rose-100 ml-2"
                          onClick={() => ingatkanWA(a.nama, a.nim, a.wa,
                            `السلام عليكم ${a.nama}\n\nKakak belum login ke Ma'had Lughah hari ini. Yuk buka aplikasi, lihat materi terbaru, dan jangan sampai ketinggalan ujian.\n\nSemangat belajar! 🌟\n\n— Ketua Kamar ${kamarData.kamar.nama}`
                          )}
                        >
                          <Share2 className="w-3.5 h-3.5 mr-1" />
                          Ingatkan
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* ===== TAB: MONITORING HAFALAN ===== */}
        <TabsContent value="hafalan" className="space-y-4 mt-4">
          <Card className="rounded-2xl border border-gray-200 shadow-soft">
            <CardHeader>
              <CardTitle className="text-base flex items-center justify-between">
                <span>Monitoring Hafalan Anggota</span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={loadHafalanGrid}
                  disabled={loadingHafalan}
                  className="rounded-lg"
                >
                  {loadingHafalan ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Refresh'}
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {loadingHafalan ? <Loading /> : materiList.length === 0 ? (
                <EmptyState title="Belum ada materi dirilis" description="Materi yang sudah dirilis akan tampil di sini untuk dicentang" />
              ) : (
                <>
                  <p className="text-xs text-gray-500">
                    Klik kolom untuk centang status hafalan: <Badge variant="default" className="ml-1">belum</Badge> → <Badge variant="info" className="ml-1">hafal</Badge> → <Badge variant="warning" className="ml-1">bisa</Badge> → <Badge variant="success" className="ml-1">lancar</Badge>
                  </p>
                  <div className="overflow-x-auto scroll-thin">
                    <table className="w-full text-xs border-collapse">
                      <thead className="bg-gray-50 sticky top-0">
                        <tr>
                          <th className="text-left p-2 border-b sticky left-0 bg-gray-50">Anggota</th>
                          {materiList.slice(0, 20).map((m: any) => (
                            <th key={m.id} className="p-2 border-b min-w-[100px] text-center">
                              <div className="space-y-0.5">
                                <ArabicText size="sm" className="text-gray-900 leading-tight">{m.arabic}</ArabicText>
                                <p className="text-[10px] text-gray-500">{m.arti}</p>
                              </div>
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {hafalanGrid.map((row: any) => (
                          <tr key={row.mahasiswa.id} className="border-b hover:bg-gray-50">
                            <td className="p-2 sticky left-0 bg-white">
                              <p className="font-medium">{row.mahasiswa.nama}</p>
                              <p className="text-[10px] text-gray-500">{row.mahasiswa.nim}</p>
                            </td>
                            {row.materi.slice(0, 20).map((cell: any) => (
                              <td key={cell.materi.id} className="p-1 text-center">
                                <button
                                  onClick={() => {
                                    const next = cell.status === 'belum' ? 'hafal'
                                      : cell.status === 'hafal' ? 'bisa'
                                      : cell.status === 'bisa' ? 'lancar'
                                      : 'belum'
                                    updateHafalan(row.mahasiswa.id, cell.materi.id, next)
                                  }}
                                  className={`w-9 h-9 rounded-lg text-[10px] font-bold transition-all ${
                                    cell.status === 'belum' ? 'bg-gray-100 text-gray-400 hover:bg-gray-200' :
                                    cell.status === 'hafal' ? 'bg-blue-100 text-blue-700 hover:bg-blue-200' :
                                    cell.status === 'bisa' ? 'bg-amber-100 text-amber-700 hover:bg-amber-200' :
                                    'bg-emerald-100 text-emerald-700 hover:bg-emerald-200'
                                  }`}
                                  title={`${cell.materi.arti} — status: ${cell.status}${cell.centangBy ? ` (oleh ${cell.centangBy})` : ''}`}
                                >
                                  {cell.status === 'belum' ? '○' : cell.status === 'hafal' ? 'H' : cell.status === 'bisa' ? 'B' : 'L'}
                                </button>
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ===== TAB: BELUM LIHAT MATERI ===== */}
        <TabsContent value="belum-view" className="space-y-4 mt-4">
          <Card className="rounded-2xl border border-gray-200 shadow-soft">
            <CardHeader>
              <CardTitle className="text-base flex items-center justify-between">
                <span>Anggota Belum Lihat Materi Hari Ini</span>
                <Badge variant="warning">{belumViewData.length} materi</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {loadingBelumView ? <Loading /> : belumViewData.length === 0 ? (
                <EmptyState title="Semua anggota sudah lihat semua materi hari ini" description="Bagus! Semua anggota sudah membuka materi terbaru" />
              ) : (
                belumViewData.map((item: any, i: number) => (
                  <div key={i} className="border rounded-xl p-3">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <ArabicText size="md" className="text-gray-900">{item.materi.arabic}</ArabicText>
                        <p className="text-sm font-medium">{item.materi.arti}</p>
                        <p className="text-xs text-gray-500 mt-0.5">
                          {item.sudahView} sudah lihat · {item.belumView.length} belum
                        </p>
                      </div>
                    </div>
                    {item.belumView.length > 0 && (
                      <div className="mt-2 pt-2 border-t border-dashed">
                        <p className="text-xs text-gray-600 mb-1.5 font-semibold">Belum lihat:</p>
                        <div className="flex flex-wrap gap-2">
                          {item.belumView.map((m: any) => (
                            <Button
                              key={m.id}
                              size="sm"
                              variant="outline"
                              className="rounded-lg bg-amber-50 border-amber-200 text-amber-700 hover:bg-amber-100 h-7 text-xs"
                              onClick={() => ingatkanWA(m.nama, m.nim, m.wa,
                                `السلام عليكم ${m.nama}\n\nKakak belum membuka materi hari ini: ${item.materi.arabic} (${item.materi.arti}).\n\nYuk buka aplikasi Ma'had Lughah sekarang, agar tidak ketinggalan materi dan dapat mengikuti ujian dengan baik.\n\nSemangat! 📚\n\n— Ketua Kamar`
                              )}
                            >
                              {m.nama} <Share2 className="w-3 h-3 ml-1" />
                            </Button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
