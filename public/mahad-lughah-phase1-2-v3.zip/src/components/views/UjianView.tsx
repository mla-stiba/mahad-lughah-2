'use client'

import { useState, useEffect, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Progress } from '@/components/ui/progress'
import { toast } from '@/hooks/use-toast'
import { useAntiCheat } from '@/hooks/use-anti-cheat'
import { openWhatsAppShare, formatHasilUjianMessage } from '@/lib/wa-share'
import { ArabicText, EmptyState, Loading, Badge } from '@/components/shared'
import { getGrade, MumtazCelebration } from '@/components/shared/grade'
import { Share2, AlertTriangle } from 'lucide-react'

interface MahasiswaSession {
  role: 'mahasiswa'
  mahasiswa: any
}

export function UjianView({ session }: { session: MahasiswaSession }) {
  const [loading, setLoading] = useState(true)
  const [available, setAvailable] = useState<any[]>([])
  const [activeSesi, setActiveSesi] = useState<any | null>(null)
  const [hasil, setHasil] = useState<any | null>(null)
  const [currentIdx, setCurrentIdx] = useState(0)
  const [jawaban, setJawaban] = useState<Record<string, string>>({})
  const [matchingAnswer, setMatchingAnswer] = useState<Record<string, string>>({}) // {leftArabic: rightArti}
  const [submitting, setSubmitting] = useState(false)
  const [done, setDone] = useState(false)
  const [view, setView] = useState<'ujian' | 'evaluasi'>('ujian')

  // Anti-cheat aktif hanya saat user sedang mengerjakan ujian (bukan saat done/evaluasi)
  const antiCheatEnabled = !!activeSesi && !done && view === 'ujian'
  const { showWarning, setShowWarning } = useAntiCheat(antiCheatEnabled, useCallback((v) => {
    const labels: Record<string, string> = {
      screenshot: '📸 Screenshot terdeteksi!',
      copy: '📋 Salin teks diblokir!',
      paste: '📋 Paste diblokir!',
      devtools: '⚙️ DevTools terdeteksi!',
      print: '🖨️ Print diblokir!',
      contextmenu: '🖱️ Right-click diblokir!',
      blur: '👁️ Anda meninggalkan halaman ujian!',
    }
    toast({
      title: labels[v.type] || 'Pelanggaran terdeteksi',
      description: 'Aktivitas ini dicatat. Hati-hati, ini bisa mempengaruhi hasil ujian Anda.',
      variant: 'destructive',
    })
  }, []))

  function shareWhatsApp() {
    if (!hasil || !activeSesi) return
    const skor = hasil.skorTotal || 0
    const grade = getGrade(skor)
    const message = formatHasilUjianMessage({
      mahasiswaNama: session.mahasiswa.nama,
      mahasiswaNim: session.mahasiswa.nim,
      sesiNama: activeSesi.nama,
      skor,
      jumlahBenar: hasil.jumlahBenar || 0,
      jumlahSoal: hasil.jumlahSoal || 0,
      gradeArabic: grade.arabic,
      gradeLetter: grade.letter,
      appUrl: typeof window !== 'undefined' ? window.location.origin : undefined,
    })
    // Share tanpa nomor - user pilih kontak sendiri di WA
    openWhatsAppShare(null, message)
    toast({ title: 'Dibuka di WhatsApp', description: 'Pilih kontak/grup untuk share hasil' })
  }

  async function loadAvailable() {
    setLoading(true)
    const r = await fetch(`/api/ujian?action=available&mahasiswaId=${session.mahasiswa.id}`).then(r => r.json())
    setAvailable(r.data || [])
    setLoading(false)
  }

  useEffect(() => { loadAvailable() }, [])

  async function startUjian(sesi: any) {
    setLoading(true)
    setActiveSesi(sesi)
    setDone(false)
    // Get detail sesi + cek apakah sudah ada hasil
    const r = await fetch(`/api/ujian?action=detail&sesiId=${sesi.id}&mahasiswaId=${session.mahasiswa.id}`).then(r => r.json())
    const data = r.data
    setActiveSesi(data.sesi)
    setHasil(data.hasil)

    // Start jika belum ada
    if (!data.hasil || data.hasil.status === 'ongoing') {
      const startR = await fetch(`/api/ujian?action=start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sesiId: sesi.id, mahasiswaId: session.mahasiswa.id }),
      }).then(r => r.json())
      setHasil(startR.data)
    }

    // Init jawaban
    const initJ: Record<string, string> = {}
    const initM: Record<string, string> = {}
    for (const s of data.sesi.soal) {
      if (s.jenis === 'matching' && s.opsiJson) {
        const opsi = JSON.parse(s.opsiJson)
        opsi.shuffled?.forEach((sh: any) => {
          // initial: kosong
        })
      }
    }
    setJawaban(initJ)
    setMatchingAnswer(initM)
    setCurrentIdx(0)
    setLoading(false)
  }

  function setJawabanForSoal(soalId: string, val: string) {
    setJawaban(prev => ({ ...prev, [soalId]: val }))
  }

  function setMatchingForLeft(leftArabic: string, rightArti: string) {
    setMatchingAnswer(prev => ({ ...prev, [leftArabic]: rightArti }))
  }

  async function submit() {
    if (!activeSesi || !hasil) return
    if (!confirm('Kumpulkan jawaban? Setelah dikumpulkan tidak bisa diubah.')) return

    setSubmitting(true)
    const jawabanArr: any[] = []

    for (const s of activeSesi.soal) {
      if (s.jenis === 'matching') {
        // Build matching pairs
        const opsi = s.opsiJson ? JSON.parse(s.opsiJson) : null
        const pairs = opsi?.pairs?.map((p: any) => ({
          left: p.arabic,
          right: matchingAnswer[p.arabic] || '',
        })) || []
        jawabanArr.push({ soalId: s.id, jawaban: JSON.stringify(pairs) })
      } else if (s.jenis === 'audio') {
        // Audio sekarang: mahasiswa dengarkan + jawab teks (auto-koreksi)
        jawabanArr.push({ soalId: s.id, jawaban: jawaban[s.id] || '' })
      } else {
        jawabanArr.push({ soalId: s.id, jawaban: jawaban[s.id] || '' })
      }
    }

    const r = await fetch('/api/ujian?action=submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ hasilId: hasil.id, jawaban: jawabanArr }),
    }).then(r => r.json())

    if (r.data) {
      setHasil(r.data)
      setDone(true)
      toast({ title: 'Jawaban terkumpul!' })
    }
    setSubmitting(false)
  }

  async function handleRetry() {
    if (!activeSesi) return
    const res = await fetch('/api/ujian?action=retry', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sesiId: activeSesi.id, mahasiswaId: session.mahasiswa.id }),
    })
    const data = await res.json()
    if (res.ok) {
      toast({ title: 'Coba ulang dimulai', description: 'Nilai asli tidak akan berubah' })
      // Start retry session
      setHasil(data.data)
      setDone(false)
      setJawaban({})
      setCurrentIdx(0)
      setView('ujian')
      loadDetail(activeSesi.id)
    } else {
      toast({ title: 'Gagal', description: data.error, variant: 'destructive' })
    }
  }

  async function loadDetail(sesiId: string) {
    const r = await fetch(`/api/ujian?action=detail&sesiId=${sesiId}&mahasiswaId=${session.mahasiswa.id}`).then(r => r.json())
    const data = r.data
    setActiveSesi(data.sesi)
    setHasil(data.hasil)
    setJawaban({})
    setMatchingAnswer({})
    setCurrentIdx(0)
  }

  // Evaluasi view (kunci jawaban setelah deadline)
  const [evaluasiData, setEvaluasiData] = useState<any | null>(null)
  const [evaluasiLoading, setEvaluasiLoading] = useState(false)

  async function loadEvaluasi(sesiId: string) {
    setEvaluasiLoading(true)
    const r = await fetch(`/api/ujian?action=evaluasi&sesiId=${sesiId}&mahasiswaId=${session.mahasiswa.id}`).then(r => r.json())
    if (r.data) {
      setEvaluasiData(r.data)
    } else {
      toast({ title: 'Evaluasi belum tersedia', description: r.error, variant: 'destructive' })
    }
    setEvaluasiLoading(false)
  }
  if (loading) return <Loading />

  if (done && hasil) {
    const skor = hasil.skorTotal || 0
    const grade = getGrade(skor)
    return (
      <div className="space-y-6 max-w-2xl mx-auto">
        <MumtazCelebration show={grade.isMumtaz} />
        <Card className="text-center border-0 shadow-float animate-pop-in">
          <CardHeader>
            <CardTitle className="text-2xl font-display text-gray-900">Jawaban Terkumpul!</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-col items-center gap-3">
              <p className="text-sm text-gray-500">Skor Anda:</p>
              <p className={`text-6xl font-bold ${grade.color}`}>{skor.toFixed(1)}%</p>
              <div className={`inline-flex items-center gap-3 px-4 py-2 rounded-full ${grade.bgClass}`}>
                <span className={`font-arabic text-2xl ${grade.color}`}>{grade.arabic}</span>
                <span className={`text-sm font-semibold ${grade.color}`}>({grade.letter})</span>
              </div>
              <p className="text-sm text-gray-500">Benar: {hasil.jumlahBenar}/{hasil.jumlahSoal} soal</p>
            </div>

            {/* Share WA button — Fitur #6 */}
            <div className="flex flex-wrap gap-2 justify-center pt-2">
              <Button
                onClick={shareWhatsApp}
                variant="outline"
                className="rounded-xl bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100"
              >
                <Share2 className="w-4 h-4 mr-1.5" />
                Share Hasil ke WhatsApp
              </Button>
            </div>

            {/* Evaluasi & Coba Ulang — terkunci sampai deadline lewat */}
            <div className={`mt-6 p-4 rounded-2xl border-2 ${activeSesi?.deadlinePassed ? 'border-emerald-300 bg-emerald-50/50' : 'border-gray-200 bg-gray-50'}`}>
              {activeSesi?.deadlinePassed ? (
                <div className="space-y-3">
                  <p className="text-sm font-semibold text-emerald-700">✓ Batas waktu telah berakhir — Anda dapat melihat kunci jawaban dan mencoba ulang</p>
                  <div className="flex gap-2 justify-center">
                    <Button
                      onClick={() => { loadEvaluasi(activeSesi.id); setView('evaluasi') }}
                      className="rounded-xl bg-emerald-600 hover:bg-emerald-700"
                    >
                      Lihat Kunci Jawaban
                    </Button>
                    <Button
                      onClick={handleRetry}
                      variant="outline"
                      className="rounded-xl"
                    >
                      Coba Ulang (tidak ubah nilai)
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="text-sm font-semibold text-gray-500">🔒 Evaluasi & Coba Ulang</p>
                  <p className="text-xs text-gray-400">
                    Terkunci sampai batas waktu ujian berakhir
                    {activeSesi?.jamSelesai && ` (jam ${activeSesi.jamSelesai})`}
                  </p>
                </div>
              )}
            </div>

            <Button onClick={() => { setActiveSesi(null); setDone(false); loadAvailable() }} variant="outline" className="rounded-xl">
              Kembali ke Daftar Ujian
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Evaluasi view (kunci jawaban setelah deadline lewat)
  if (view === 'evaluasi' && activeSesi) {
    if (evaluasiLoading) return <Loading />
    if (!evaluasiData) {
      return (
        <div className="space-y-6 max-w-3xl mx-auto">
          <Button variant="ghost" onClick={() => setView('ujian')} className="mb-2">← Kembali</Button>
          <Card className="rounded-2xl border border-gray-200 shadow-soft">
            <CardContent>
              <EmptyState
                title="Evaluasi belum tersedia"
                description="Evaluasi baru tersedia setelah batas waktu ujian berakhir dan Anda telah mengumpulkan jawaban"
              />
              <div className="text-center mt-4">
                <Button onClick={() => loadEvaluasi(activeSesi.id)} className="rounded-xl bg-emerald-600 hover:bg-emerald-700">
                  Coba Muat Evaluasi
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )
    }

    const skor = evaluasiData.hasil?.skorTotal || 0
    const grade = getGrade(skor)
    return (
      <div className="space-y-6 max-w-3xl mx-auto">
        <MumtazCelebration show={grade.isMumtaz} />
        <div className="flex items-center justify-between">
          <Button variant="ghost" onClick={() => { setView('ujian'); setEvaluasiData(null) }} className="mb-2">← Kembali</Button>
          <Badge variant="success">Evaluasi - Kunci Jawaban</Badge>
        </div>

        {/* Score card */}
        <Card className="text-center border-0 shadow-float">
          <CardContent className="pt-6 pb-6">
            <p className="text-sm text-gray-500">Skor Anda:</p>
            <p className={`text-5xl font-bold ${grade.color}`}>{skor.toFixed(1)}%</p>
            <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full ${grade.bgClass} mt-2`}>
              <span className={`font-arabic text-xl ${grade.color}`}>{grade.arabic}</span>
              <span className={`text-xs ${grade.color}`}>({grade.letter})</span>
            </div>
            <p className="text-sm text-gray-500 mt-2">{evaluasiData.hasil?.jumlahBenar}/{evaluasiData.hasil?.jumlahSoal} soal benar</p>
          </CardContent>
        </Card>

        {/* Soal + kunci jawaban + jawaban mahasiswa */}
        {evaluasiData.sesi.soal.map((s: any, i: number) => {
          const detail = evaluasiData.hasil?.detail?.find((d: any) => d.soalId === s.id)
          return (
            <Card key={s.id} className="rounded-2xl border border-gray-200 shadow-soft">
              <CardContent className="p-5 space-y-3">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-[oklch(0.50_0.18_265)]">#{i + 1}</span>
                  <Badge variant="info">{s.jenis}</Badge>
                  {detail?.benar === true && <Badge variant="success">✓ Benar</Badge>}
                  {detail?.benar === false && <Badge variant="danger">✗ Salah</Badge>}
                </div>
                <p className="text-gray-800">{s.pertanyaan}</p>
                {s.pertanyaanArabic && (
                  <ArabicText size="lg" className="text-gray-700">{s.pertanyaanArabic}</ArabicText>
                )}
                {s.jenis === 'mcq' && s.opsiJson && (
                  <div className="text-sm text-gray-600 space-y-1">
                    {JSON.parse(s.opsiJson).map((o: string, idx: number) => (
                      <div key={idx} className={`p-2 rounded-lg ${o === s.jawabanBenar ? 'bg-emerald-50 border border-emerald-200' : 'bg-gray-50'}`}>
                        {o === s.jawabanBenar ? '✓ ' : '○ '}{o}
                      </div>
                    ))}
                  </div>
                )}
                <div className="grid grid-cols-2 gap-3 pt-2 border-t border-gray-100">
                  <div>
                    <p className="text-xs font-semibold text-gray-500 uppercase">Jawaban Benar</p>
                    {s.jawabanBenar && <ArabicText size="md" className="text-emerald-700">{s.jawabanBenar}</ArabicText>}
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-gray-500 uppercase">Jawaban Anda</p>
                    {detail?.jawaban ? <ArabicText size="md" className={detail.benar ? 'text-emerald-700' : 'text-rose-600'}>{detail.jawaban}</ArabicText> : <span className="text-gray-400 text-sm italic">kosong</span>}
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}

        {/* Retry warning */}
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl">
          <p className="text-sm text-amber-800">
            ⚠️ <strong>Coba Ulang:</strong> Anda dapat mencoba ulang ujian ini dengan soal & urutan yang sama.
            Hasil coba ulang <strong>tidak akan mengubah nilai asli</strong> yang sudah tersimpan.
          </p>
          <Button onClick={handleRetry} className="mt-3 rounded-xl bg-amber-600 hover:bg-amber-700">
            Coba Ulang Sekarang
          </Button>
        </div>
      </div>
    )
  }

  if (!activeSesi) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Ujian</h2>
          <p className="text-sm text-gray-500 mt-1">Pilih sesi untuk dikerjakan, {session.mahasiswa.nama}</p>
        </div>
        {available.length === 0 ? (
          <EmptyState title="Belum ada ujian aktif" description="Tunggu penguji membuka sesi ujian" />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {available.map(s => (
              <Card key={s.id} className={s.hasil?.length > 0 ? 'border-amber-300' : 'border-emerald-300'}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-base">{s.nama}</CardTitle>
                    {s.hasil?.length > 0 && <Badge variant="warning">Sudah dikerjakan</Badge>}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-xs text-gray-500 mb-2">{s.level?.nama}</p>
                  <div className="flex gap-3 text-xs text-gray-500 mb-3">
                    <span><Badge variant="info">{s.mode}</Badge></span>
                    <span>{s.durasiMenit} menit</span>
                    <span>{s._count?.soal ?? 0} soal</span>
                  </div>
                  <Button
                    size="sm"
                    className="bg-emerald-600 hover:bg-emerald-700"
                    onClick={() => startUjian(s)}
                    disabled={s.hasil?.length > 0 && s.hasil[0].status !== 'ongoing'}
                  >
                    {s.hasil?.length > 0 && s.hasil[0].status !== 'ongoing' ? 'Sudah Selesai' : s.hasil?.length > 0 ? 'Lanjutkan' : 'Mulai Ujian'}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    )
  }

  // Active ujian
  const soalList = activeSesi.soal || []
  const currentSoal = soalList[currentIdx]
  const progress = ((currentIdx + 1) / soalList.length) * 100

  function renderSoal(soal: any) {
    if (!soal) return null

    // Helper: convert YouTube URL to embed URL
    function youtubeToEmbed(url: string): string {
      if (!url) return ''
      // Already embed
      if (url.includes('/embed/')) return url
      // youtube.com/watch?v=XXX
      const watchMatch = url.match(/[?&]v=([^&]+)/)
      if (watchMatch) return `https://www.youtube.com/embed/${watchMatch[1]}`
      // youtu.be/XXX
      const shortMatch = url.match(/youtu\.be\/([^?]+)/)
      if (shortMatch) return `https://www.youtube.com/embed/${shortMatch[1]}`
      return url
    }

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Badge variant="info">{soal.jenis}</Badge>
        </div>

        <p className="text-gray-800">{soal.pertanyaan}</p>

        {/* Display Arabic prompt if any */}
        {soal.pertanyaanArabic && (
          <div className="p-4 bg-emerald-50 rounded-lg text-right">
            <ArabicText size="xl" className="text-emerald-800">{soal.pertanyaanArabic}</ArabicText>
          </div>
        )}

        {/* MEDIA: gambar, video, audio, embed — tampil untuk SEMUA jenis soal */}
        {soal.imageUrl && (
          <div className="rounded-xl overflow-hidden border border-gray-200">
            <img src={soal.imageUrl} alt="gambar soal" className="w-full max-h-80 object-contain bg-gray-50" />
          </div>
        )}
        {soal.videoUrl && (
          <div className="rounded-xl overflow-hidden border border-gray-200">
            {soal.videoUrl.includes('youtube.com') || soal.videoUrl.includes('youtu.be') ? (
              <iframe
                src={youtubeToEmbed(soal.videoUrl)}
                className="w-full aspect-video"
                allowFullScreen
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              />
            ) : (
              <video controls src={soal.videoUrl} className="w-full max-h-80" preload="metadata" />
            )}
          </div>
        )}
        {soal.audioUrl && (
          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl">
            <p className="text-xs text-emerald-700 font-semibold mb-1">🎧 Audio</p>
            <audio controls src={soal.audioUrl} className="w-full" preload="metadata" />
          </div>
        )}
        {soal.embedUrl && (
          <div className="rounded-xl overflow-hidden border border-gray-200">
            <iframe src={soal.embedUrl} className="w-full min-h-[200px]" allowFullScreen />
          </div>
        )}

        {/* MCQ */}
        {soal.jenis === 'mcq' && (
          <RadioGroup
            value={jawaban[soal.id] || ''}
            onValueChange={(v) => setJawabanForSoal(soal.id, v)}
            className="space-y-2"
          >
            {soal.opsiJson && JSON.parse(soal.opsiJson).map((opsi: string, i: number) => (
              <div key={i} className="flex items-center space-x-2 p-2 border rounded hover:bg-gray-50">
                <RadioGroupItem value={opsi} id={`${soal.id}-${i}`} />
                <Label htmlFor={`${soal.id}-${i}`} className="cursor-pointer">{opsi}</Label>
              </div>
            ))}
          </RadioGroup>
        )}

        {/* Isian */}
        {soal.jenis === 'isian' && (
          <div className="space-y-2">
            <Input
              value={jawaban[soal.id] || ''}
              onChange={(e) => setJawabanForSoal(soal.id, e.target.value)}
              dir="rtl"
              className="font-arabic text-right text-2xl"
              placeholder="اكتب الجواب هنا"
            />
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="space-y-6 anti-cheat-zone">
      {/* Warning overlay saat pelanggaran anti-cheat terdeteksi */}
      {showWarning && (
        <div className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none">
          <div className="fixed inset-0 bg-rose-500/20 backdrop-blur-sm animate-pulse" />
          <div className="relative bg-rose-600 text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 animate-pop-in">
            <AlertTriangle className="w-6 h-6" />
            <div>
              <p className="font-bold text-base">⚠️ Peringatan Keamanan</p>
              <p className="text-sm opacity-90">Aktivitas terdeteksi. Ujian dipantau.</p>
            </div>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between">
        <div>
          <Button variant="ghost" onClick={() => { setActiveSesi(null); loadAvailable() }} className="mb-2 no-print">← Keluar</Button>
          <h2 className="text-2xl font-bold text-gray-900">{activeSesi.nama}</h2>
          <p className="text-sm text-gray-500 mt-1">{activeSesi.level?.nama} &middot; {activeSesi.durasiMenit} menit</p>
        </div>
        <Button onClick={submit} disabled={submitting} className="bg-emerald-600 hover:bg-emerald-700 no-print">
          {submitting ? 'Menyimpan...' : 'Kumpulkan'}
        </Button>
      </div>

      <div className="no-print">
        <div className="flex items-center justify-between text-sm text-gray-500 mb-2">
          <span>Soal {currentIdx + 1} dari {soalList.length}</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      <Card>
        <CardContent className="p-6">
          {renderSoal(currentSoal)}
        </CardContent>
      </Card>

      {/* Quick nav: grid 5-6 kolom compact, scrollable horizontal di mobile */}
      <div className="no-print bg-white rounded-2xl border border-gray-200 p-3 shadow-soft">
        <div className="flex items-center justify-between mb-2">
          <p className="text-xs font-semibold text-gray-600">Navigasi Soal</p>
          <span className="text-xs text-gray-500">{currentIdx + 1} / {soalList.length}</span>
        </div>
        <div className="grid grid-cols-6 sm:grid-cols-8 md:grid-cols-10 gap-1.5 max-h-32 overflow-y-auto scroll-thin">
          {soalList.map((s, i) => {
            const isAnswered = jawaban[s.id] || (s.jenis === 'matching' && Object.keys(matchingAnswer).length > 0)
            return (
              <button
                key={s.id}
                onClick={() => setCurrentIdx(i)}
                className={`aspect-square rounded-lg text-xs font-semibold transition-all ${
                  i === currentIdx
                    ? 'bg-[oklch(0.50_0.18_265)] text-white shadow-soft scale-105'
                    : isAnswered
                    ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200'
                    : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                }`}
              >
                {i + 1}
              </button>
            )
          })}
        </div>
      </div>

      {/* Nav buttons — compact inline, no more space waste */}
      <div className="flex items-center justify-between gap-2 no-print">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setCurrentIdx(Math.max(0, currentIdx - 1))}
          disabled={currentIdx === 0}
          className="rounded-xl flex-1 sm:flex-none"
        >← Sebelumnya</Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setCurrentIdx(Math.min(soalList.length - 1, currentIdx + 1))}
          disabled={currentIdx === soalList.length - 1}
          className="rounded-xl flex-1 sm:flex-none"
        >Berikutnya →</Button>
      </div>
    </div>
  )
}

// Matching Question component
function MatchingQuestion({ opsi, answer, onAnswer }: { opsi: any; answer: Record<string, string>; onAnswer: (left: string, right: string) => void }) {
  if (!opsi?.pairs || !opsi?.shuffled) return null
  return (
    <div className="space-y-3">
      <p className="text-sm text-gray-600">Pasangkan Arabic (kanan) dengan artinya (kiri):</p>
      <div className="space-y-2">
        {opsi.shuffled.map((right: any, i: number) => {
          const leftItem = opsi.pairs[i]
          return (
            <div key={i} className="flex items-center gap-3 p-2 border rounded">
              <div className="flex-1 text-right">
                <ArabicText size="md" className="text-gray-900">{leftItem.arabic}</ArabicText>
              </div>
              <select
                value={answer[leftItem.arabic] || ''}
                onChange={(e) => onAnswer(leftItem.arabic, e.target.value)}
                className="flex-2 border rounded px-2 py-1 text-sm"
              >
                <option value="">— pilih arti —</option>
                {opsi.shuffled.map((s: any, j: number) => (
                  <option key={j} value={s.arti}>{s.arti}</option>
                ))}
              </select>
            </div>
          )
        })}
      </div>
    </div>
  )
}
